import Foundation
import AVFoundation
import CoreAudio
import Combine

public struct AudioDevice: Identifiable, Hashable {
    public var id: AudioDeviceID
    public var name: String
    public var manufacturer: String
    public var hasInput: Bool
    public var hasOutput: Bool
    
    public init(id: AudioDeviceID, name: String, manufacturer: String, hasInput: Bool, hasOutput: Bool) {
        self.id = id
        self.name = name
        self.manufacturer = manufacturer
        self.hasInput = hasInput
        self.hasOutput = hasOutput
    }
}

public class AudioEngineManager: ObservableObject {
    @Published var devices: [AudioDevice] = []
    @Published var selectedInputDevice: AudioDeviceID?
    @Published var selectedOutputDevice: AudioDeviceID?
    
    @Published var isRunning = false
    @Published var bypass = false
    @Published var preamp: Double = 0.0 // dB
    @Published var balance: Double = 0.0 // -1.0 to 1.0
    @Published var channelSwap = false
    
    // Permission and Error Status
    @Published var permissionStatus: String = "Checking..."
    @Published var lastError: String? = nil
    
    // Live metering levels
    public let levelMonitor = AudioLevelMonitor()
    
    @Published var bands: [PEQBand] = [] {
        didSet {
            updateEQBands()
        }
    }
    
    public var spectrum: [Float] = Array(repeating: -80.0, count: 32)
    public let spectrumPublisher = PassthroughSubject<[Float], Never>()
    @Published var sampleRate: Double = 48000.0
    
    private var inputEngine = AVAudioEngine()
    private var outputEngine = AVAudioEngine()
    private var eqNode = AVAudioUnitEQ(numberOfBands: 16)
    private var sourceNode: AVAudioSourceNode?
    private let ringBuffer = AudioRingBuffer(capacity: 96000) // 2 seconds safety buffer
    private var levelTimer: Timer?
    private var cancellables = Set<AnyCancellable>()
    private let fftAnalyzer = FFTAnalyzer()
    private let fftQueue = DispatchQueue(label: "com.vibe.peqdbflow.fft", qos: .userInteractive)
    private var fftTimer: DispatchSourceTimer?
    
    // Atomically read levels from audio render thread
    private var peakLeftValue: Float = 0.0
    private var peakRightValue: Float = 0.0
    private var lastSpectrumUpdateTime: Double = 0.0
    
    // Volume level queried from virtual input device to perform metering normalization
    private var inputVolume: Float = 1.0
    
    // Real-time safe shadow variables to avoid reading @Published variables on real-time thread
    private var rtPreamp: Float = 0.0
    private var rtBalance: Float = 0.0
    private var rtBypass: Bool = false
    private var rtChannelSwap: Bool = false
    
    public init() {
        checkPermission()
        refreshDevices()
        setupDefaultDevices()
        startLevelTimer()
        setupStateSubscriptions()
    }
    
    deinit {
        stop()
        levelTimer?.invalidate()
    }
    
    // MARK: - Permissions Check
    public func checkPermission() {
        let status = AVCaptureDevice.authorizationStatus(for: .audio)
        switch status {
        case .authorized:
            permissionStatus = "Authorized"
        case .denied:
            permissionStatus = "Denied"
        case .restricted:
            permissionStatus = "Restricted"
        case .notDetermined:
            permissionStatus = "Not Determined"
        @unknown default:
            permissionStatus = "Unknown"
        }
    }
    
    public func requestPermission(completion: @escaping (Bool) -> Void) {
        AVCaptureDevice.requestAccess(for: .audio) { [weak self] granted in
            DispatchQueue.main.async {
                self?.checkPermission()
                completion(granted)
            }
        }
    }
    
    // MARK: - Device Enumeration
    public func refreshDevices() {
        var propertyAddress = AudioObjectPropertyAddress(
            mSelector: kAudioHardwarePropertyDevices,
            mScope: kAudioObjectPropertyScopeGlobal,
            mElement: kAudioObjectPropertyElementMain
        )
        
        var size: UInt32 = 0
        var status = AudioObjectGetPropertyDataSize(
            AudioObjectID(kAudioObjectSystemObject),
            &propertyAddress,
            0,
            nil,
            &size
        )
        
        guard status == noErr else { return }
        
        let deviceCount = Int(size) / MemoryLayout<AudioDeviceID>.size
        var deviceIDs = [AudioDeviceID](repeating: 0, count: deviceCount)
        status = AudioObjectGetPropertyData(
            AudioObjectID(kAudioObjectSystemObject),
            &propertyAddress,
            0,
            nil,
            &size,
            &deviceIDs
        )
        
        guard status == noErr else { return }
        
        var parsedDevices: [AudioDevice] = []
        for deviceID in deviceIDs {
            let name = getDeviceName(deviceID)
            let manufacturer = getDeviceManufacturer(deviceID)
            let hasInput = checkDeviceHasInput(deviceID)
            let hasOutput = checkDeviceHasOutput(deviceID)
            
            if hasInput || hasOutput {
                parsedDevices.append(AudioDevice(
                    id: deviceID,
                    name: name,
                    manufacturer: manufacturer,
                    hasInput: hasInput,
                    hasOutput: hasOutput
                ))
            }
        }
        
        self.devices = parsedDevices
    }
    
    private func setupDefaultDevices() {
        if let blackhole = devices.first(where: { $0.hasInput && $0.name.lowercased().contains("blackhole") }) {
            selectedInputDevice = blackhole.id
        } else {
            selectedInputDevice = getDefaultInputDeviceID()
        }
        
        if let fosi = devices.first(where: { $0.hasOutput && $0.name.lowercased().contains("fosi") }) {
            selectedOutputDevice = fosi.id
        } else {
            selectedOutputDevice = getDefaultOutputDeviceID()
        }
    }
    
    // MARK: - Audio Processing Pipeline Control
    public func start() {
        guard !isRunning else { return }
        
        lastError = nil
        
        let status = AVCaptureDevice.authorizationStatus(for: .audio)
        if status == .notDetermined {
            requestPermission { [weak self] granted in
                if granted {
                    self?.startPipeline()
                } else {
                    self?.lastError = "Microphone permission is required to capture audio from loopback devices."
                }
            }
        } else if status == .authorized {
            startPipeline()
        } else {
            lastError = "Microphone permission is denied. Enable it in System Settings > Privacy & Security > Microphone."
        }
    }
    
    private func startPipeline() {
        guard let inputID = selectedInputDevice, let outputID = selectedOutputDevice else {
            lastError = "Please select both input and output devices before activating."
            return
        }
        
        ringBuffer.clear()
        
        // Query initial system volume for metering normalization
        self.inputVolume = getDeviceVolume(inputID, isInput: false)
        
        // Pre-configure maximum frames per slice on all default engine nodes to prevent kAudioUnitErr_TooManyFramesToProcess (-10877)
        inputEngine.inputNode.auAudioUnit.maximumFramesToRender = 8192
        inputEngine.outputNode.auAudioUnit.maximumFramesToRender = 8192
        inputEngine.mainMixerNode.auAudioUnit.maximumFramesToRender = 8192
        
        outputEngine.outputNode.auAudioUnit.maximumFramesToRender = 8192
        outputEngine.mainMixerNode.auAudioUnit.maximumFramesToRender = 8192
        eqNode.auAudioUnit.maximumFramesToRender = 8192
        
        // 1. Configure Input Engine
        let inputUnit = inputEngine.inputNode.audioUnit!
        var inID = inputID
        var status = AudioUnitSetProperty(
            inputUnit,
            kAudioOutputUnitProperty_CurrentDevice,
            kAudioUnitScope_Global,
            0,
            &inID,
            UInt32(MemoryLayout<AudioDeviceID>.size)
        )
        guard status == noErr else {
            lastError = "Failed to set input device (Error: \(status))"
            return
        }
        
        // Match inputEngine output device to the same loopback ID to satisfy AVAudioEngine clock domain requirements
        let inputOutputUnit = inputEngine.outputNode.audioUnit!
        status = AudioUnitSetProperty(
            inputOutputUnit,
            kAudioOutputUnitProperty_CurrentDevice,
            kAudioUnitScope_Global,
            0,
            &inID,
            UInt32(MemoryLayout<AudioDeviceID>.size)
        )
        guard status == noErr else {
            lastError = "Failed to set clock domain matching on input engine (Error: \(status))"
            return
        }
        
        let inputFormat = inputEngine.inputNode.inputFormat(forBus: 0)
        inputEngine.inputNode.installTap(onBus: 0, bufferSize: 512, format: inputFormat) { [weak self] (buffer, time) in
            guard let self = self else { return }
            guard let channelData = buffer.floatChannelData else { return }
            let frameCount = Int(buffer.frameLength)
            
            let left = channelData[0]
            let right = buffer.format.channelCount > 1 ? channelData[1] : channelData[0]
            
            self.ringBuffer.write(left: left, right: right, count: frameCount)
        }
        
        // 2. Configure Output Engine (only output node is active)
        let outputUnit = outputEngine.outputNode.audioUnit!
        var outID = outputID
        status = AudioUnitSetProperty(
            outputUnit,
            kAudioOutputUnitProperty_CurrentDevice,
            kAudioUnitScope_Global,
            0,
            &outID,
            UInt32(MemoryLayout<AudioDeviceID>.size)
        )
        guard status == noErr else {
            lastError = "Failed to set output device (Error: \(status))"
            inputEngine.inputNode.removeTap(onBus: 0)
            return
        }
        
        let outputSampleRate = getDeviceSampleRate(outputID)
        DispatchQueue.main.async {
            self.sampleRate = outputSampleRate
        }
        let processFormat = AVAudioFormat(standardFormatWithSampleRate: outputSampleRate, channels: 2)!
        
        let unsafeSelf = Unmanaged.passUnretained(self)
        let source = AVAudioSourceNode { (isSilence, timestamp, frameCount, audioBufferList) -> OSStatus in
            let localSelf = unsafeSelf.takeUnretainedValue()
            
            let buffers = UnsafeMutableAudioBufferListPointer(audioBufferList)
            guard buffers.count >= 2 else { return noErr }
            
            let left = buffers[0].mData?.assumingMemoryBound(to: Float.self)
            let right = buffers[1].mData?.assumingMemoryBound(to: Float.self)
            
            guard let leftPtr = left, let rightPtr = right else { return noErr }
            
            _ = localSelf.ringBuffer.read(left: leftPtr, right: rightPtr, count: Int(frameCount))
            
            if localSelf.rtChannelSwap {
                for i in 0..<Int(frameCount) {
                    let temp = leftPtr[i]
                    leftPtr[i] = rightPtr[i]
                    rightPtr[i] = temp
                }
            }
            
            var maxL: Float = 0.0
            var maxR: Float = 0.0
            
            let preampFactor = pow(10.0, localSelf.rtPreamp / 20.0)
            let balanceL = localSelf.rtBalance <= 0.0 ? 1.0 : Float(1.0 - localSelf.rtBalance)
            let balanceR = localSelf.rtBalance >= 0.0 ? 1.0 : Float(1.0 + localSelf.rtBalance)
            
            let scaleL = localSelf.rtBypass ? 1.0 : (preampFactor * balanceL)
            let scaleR = localSelf.rtBypass ? 1.0 : (preampFactor * balanceR)
            
            let v = localSelf.inputVolume
            let invV = v > 0.01 ? (1.0 / v) : 0.0
            
            for i in 0..<Int(frameCount) {
                // Reconstruct full-scale signal for metering
                let normL = leftPtr[i] * invV
                let normR = rightPtr[i] * invV
                
                let procL = normL * scaleL
                let procR = normR * scaleR
                
                let absL = abs(procL)
                let absR = abs(procR)
                if absL > maxL { maxL = absL }
                if absR > maxR { maxR = absR }
                
                // Write soft-clipped output inline
                let outL = leftPtr[i] * scaleL
                let absOutL = abs(outL)
                if absOutL <= 0.9 {
                    leftPtr[i] = outL
                } else {
                    let sign: Float = outL > 0.0 ? 1.0 : -1.0
                    leftPtr[i] = sign * (0.9 + 0.1 * tanh((absOutL - 0.9) / 0.1))
                }
                
                let outR = rightPtr[i] * scaleR
                let absOutR = abs(outR)
                if absOutR <= 0.9 {
                    rightPtr[i] = outR
                } else {
                    let sign: Float = outR > 0.0 ? 1.0 : -1.0
                    rightPtr[i] = sign * (0.9 + 0.1 * tanh((absOutR - 0.9) / 0.1))
                }
            }
            
            localSelf.peakLeftValue = maxL
            localSelf.peakRightValue = maxR
            
            return noErr
        }
            
        self.sourceNode = source
        outputEngine.attach(source)
        outputEngine.attach(eqNode)
        
        // Connect Pipeline: Source -> EQ -> Main Mixer -> OutputNode
        outputEngine.connect(source, to: eqNode, format: processFormat)
        outputEngine.connect(eqNode, to: outputEngine.mainMixerNode, format: processFormat)
        
        // Configure maximum frames per slice to 8192 on all active units to prevent -10877
        let nodesToConfigure = [
            eqNode,
            outputEngine.outputNode,
            outputEngine.mainMixerNode,
            source,
            inputEngine.inputNode,
            inputEngine.outputNode,
            inputEngine.mainMixerNode
        ]
        
        for node in nodesToConfigure {
            node.auAudioUnit.maximumFramesToRender = 8192
        }
        
        updateEQBands()
        
        do {
            try inputEngine.start()
            try outputEngine.start()
            isRunning = true
            lastError = nil
            startFFTTimer()
            print("Dual engine loopback running successfully.")
        } catch {
            lastError = "Engine Start Failure: \(error.localizedDescription)"
            stop()
        }
    }
    
    public func stop() {
        stopFFTTimer()
        
        inputEngine.stop()
        inputEngine.inputNode.removeTap(onBus: 0)
        
        outputEngine.stop()
        if let source = sourceNode {
            outputEngine.detach(source)
            self.sourceNode = nil
        }
        
        isRunning = false
        levelMonitor.levelLeft = 0.0
        levelMonitor.levelRight = 0.0
        peakLeftValue = 0.0
        peakRightValue = 0.0
        print("Dual engine loopback stopped.")
    }
    
    public func restart() {
        stop()
        start()
    }
    
    private func startFFTTimer() {
        stopFFTTimer()
        let timer = DispatchSource.makeTimerSource(queue: fftQueue)
        timer.schedule(deadline: .now(), repeating: .milliseconds(33))
        
        timer.setEventHandler { [weak self] in
            guard let self = self, self.isRunning else { return }
            
            var analysisBuffer = [Float](repeating: 0.0, count: 512)
            analysisBuffer.withUnsafeMutableBufferPointer { ptr in
                if let baseAddress = ptr.baseAddress {
                    self.ringBuffer.readLatest(left: baseAddress, count: 512)
                }
            }
            
            let spec = self.fftAnalyzer.analyze(buffer: analysisBuffer, count: 512, sampleRate: self.sampleRate)
            DispatchQueue.main.async {
                self.spectrum = spec
                self.spectrumPublisher.send(spec)
            }
        }
        
        self.fftTimer = timer
        timer.resume()
    }
    
    private func stopFFTTimer() {
        fftTimer?.cancel()
        fftTimer = nil
    }
    
    // MARK: - EQ Live Updates
    public func updateEQBands() {
        let maxBands = eqNode.bands.count
        for i in 0..<maxBands {
            let eqBand = eqNode.bands[i]
            if i < bands.count {
                let customBand = bands[i]
                eqBand.bypass = !customBand.isEnabled
                eqBand.frequency = Float(customBand.frequency)
                eqBand.gain = Float(customBand.gain)
                eqBand.bandwidth = Float(qToBandwidth(customBand.q))
                
                switch customBand.type {
                case .peak: eqBand.filterType = .parametric
                case .lowShelf: eqBand.filterType = .lowShelf
                case .highShelf: eqBand.filterType = .highShelf
                case .lowPass: eqBand.filterType = .lowPass
                case .highPass: eqBand.filterType = .highPass
                }
            } else {
                eqBand.bypass = true
                eqBand.gain = 0.0
            }
        }
    }
    
    private func qToBandwidth(_ q: Double) -> Double {
        let temp = 1.0 / (2.0 * q)
        let octaves = 2.0 * log2(temp + sqrt(temp * temp + 1.0))
        return max(0.05, min(5.0, octaves))
    }
    
    // MARK: - Level Meter Timer
    private func startLevelTimer() {
        levelTimer = Timer.scheduledTimer(withTimeInterval: 0.05, repeats: true) { [weak self] _ in
            guard let self = self else { return }
            if self.isRunning {
                if let inputID = self.selectedInputDevice {
                    self.inputVolume = self.getDeviceVolume(inputID, isInput: false)
                }
                
                let decay: Float = 0.8
                self.levelMonitor.levelLeft = max(self.peakLeftValue, self.levelMonitor.levelLeft * decay)
                self.levelMonitor.levelRight = max(self.peakRightValue, self.levelMonitor.levelRight * decay)
                
                self.peakLeftValue *= 0.1
                self.peakRightValue *= 0.1
            } else {
                self.levelMonitor.levelLeft = 0.0
                self.levelMonitor.levelRight = 0.0
            }
        }
    }
    
    // MARK: - Core Audio Device Helpers
    private func getDeviceName(_ deviceID: AudioDeviceID) -> String {
        var propertyAddress = AudioObjectPropertyAddress(
            mSelector: kAudioDevicePropertyDeviceNameCFString,
            mScope: kAudioObjectPropertyScopeGlobal,
            mElement: kAudioObjectPropertyElementMain
        )
        var deviceName: Unmanaged<CFString>?
        var size = UInt32(MemoryLayout<CFString?>.size)
        let status = AudioObjectGetPropertyData(
            deviceID,
            &propertyAddress,
            0,
            nil,
            &size,
            &deviceName
        )
        if status == noErr, let name = deviceName {
            return name.takeRetainedValue() as String
        }
        return "Device ID: \(deviceID)"
    }
    
    private func getDeviceManufacturer(_ deviceID: AudioDeviceID) -> String {
        var propertyAddress = AudioObjectPropertyAddress(
            mSelector: kAudioDevicePropertyDeviceManufacturerCFString,
            mScope: kAudioObjectPropertyScopeGlobal,
            mElement: kAudioObjectPropertyElementMain
        )
        var manufacturer: Unmanaged<CFString>?
        var size = UInt32(MemoryLayout<CFString?>.size)
        let status = AudioObjectGetPropertyData(
            deviceID,
            &propertyAddress,
            0,
            nil,
            &size,
            &manufacturer
        )
        if status == noErr, let man = manufacturer {
            return man.takeRetainedValue() as String
        }
        return "Generic"
    }
    
    private func checkDeviceHasInput(_ deviceID: AudioDeviceID) -> Bool {
        var propertyAddress = AudioObjectPropertyAddress(
            mSelector: kAudioDevicePropertyStreamConfiguration,
            mScope: kAudioObjectPropertyScopeInput,
            mElement: kAudioObjectPropertyElementMain
        )
        var size: UInt32 = 0
        var status = AudioObjectGetPropertyDataSize(
            deviceID,
            &propertyAddress,
            0,
            nil,
            &size
        )
        if status == noErr && size > 0 {
            let bufferList = UnsafeMutablePointer<AudioBufferList>.allocate(capacity: Int(size))
            defer { bufferList.deallocate() }
            status = AudioObjectGetPropertyData(
                deviceID,
                &propertyAddress,
                0,
                nil,
                &size,
                bufferList
            )
            if status == noErr {
                let buffers = UnsafeMutableAudioBufferListPointer(bufferList)
                var channels = 0
                for i in 0..<buffers.count {
                    channels += Int(buffers[i].mNumberChannels)
                }
                return channels > 0
            }
        }
        return false
    }
    
    private func checkDeviceHasOutput(_ deviceID: AudioDeviceID) -> Bool {
        var propertyAddress = AudioObjectPropertyAddress(
            mSelector: kAudioDevicePropertyStreamConfiguration,
            mScope: kAudioObjectPropertyScopeOutput,
            mElement: kAudioObjectPropertyElementMain
        )
        var size: UInt32 = 0
        var status = AudioObjectGetPropertyDataSize(
            deviceID,
            &propertyAddress,
            0,
            nil,
            &size
        )
        if status == noErr && size > 0 {
            let bufferList = UnsafeMutablePointer<AudioBufferList>.allocate(capacity: Int(size))
            defer { bufferList.deallocate() }
            status = AudioObjectGetPropertyData(
                deviceID,
                &propertyAddress,
                0,
                nil,
                &size,
                bufferList
            )
            if status == noErr {
                let buffers = UnsafeMutableAudioBufferListPointer(bufferList)
                var channels = 0
                for i in 0..<buffers.count {
                    channels += Int(buffers[i].mNumberChannels)
                }
                return channels > 0
            }
        }
        return false
    }
    
    private func getDeviceSampleRate(_ deviceID: AudioDeviceID) -> Double {
        var propertyAddress = AudioObjectPropertyAddress(
            mSelector: kAudioDevicePropertyNominalSampleRate,
            mScope: kAudioObjectPropertyScopeGlobal,
            mElement: kAudioObjectPropertyElementMain
        )
        var sampleRate: Double = 48000.0
        var size = UInt32(MemoryLayout<Double>.size)
        let status = AudioObjectGetPropertyData(
            deviceID,
            &propertyAddress,
            0,
            nil,
            &size,
            &sampleRate
        )
        return status == noErr ? sampleRate : 48000.0
    }
    
    private func getDefaultInputDeviceID() -> AudioDeviceID {
        var propertyAddress = AudioObjectPropertyAddress(
            mSelector: kAudioHardwarePropertyDefaultInputDevice,
            mScope: kAudioObjectPropertyScopeGlobal,
            mElement: kAudioObjectPropertyElementMain
        )
        var deviceID = AudioDeviceID(0)
        var size = UInt32(MemoryLayout<AudioDeviceID>.size)
        _ = AudioObjectGetPropertyData(
            AudioObjectID(kAudioObjectSystemObject),
            &propertyAddress,
            0,
            nil,
            &size,
            &deviceID
        )
        return deviceID
    }
    
    private func getDefaultOutputDeviceID() -> AudioDeviceID {
        var propertyAddress = AudioObjectPropertyAddress(
            mSelector: kAudioHardwarePropertyDefaultOutputDevice,
            mScope: kAudioObjectPropertyScopeGlobal,
            mElement: kAudioObjectPropertyElementMain
        )
        var deviceID = AudioDeviceID(0)
        var size = UInt32(MemoryLayout<AudioDeviceID>.size)
        _ = AudioObjectGetPropertyData(
            AudioObjectID(kAudioObjectSystemObject),
            &propertyAddress,
            0,
            nil,
            &size,
            &deviceID
        )
        return deviceID
    }
    
    private func maximizeDeviceVolume(_ deviceID: AudioDeviceID, isInput: Bool) {
        let scope = isInput ? kAudioObjectPropertyScopeInput : kAudioObjectPropertyScopeOutput
        var propertyAddress = AudioObjectPropertyAddress(
            mSelector: kAudioDevicePropertyVolumeScalar,
            mScope: scope,
            mElement: kAudioObjectPropertyElementMain
        )
        
        var isWritable: DarwinBoolean = false
        var status = AudioObjectIsPropertySettable(deviceID, &propertyAddress, &isWritable)
        if status == noErr && isWritable.boolValue {
            var volume: Float = 1.0
            let size = UInt32(MemoryLayout<Float>.size)
            _ = AudioObjectSetPropertyData(
                deviceID,
                &propertyAddress,
                0,
                nil,
                size,
                &volume
            )
        }
        
        for channel in UInt32(1)...UInt32(2) {
            var chanAddress = AudioObjectPropertyAddress(
                mSelector: kAudioDevicePropertyVolumeScalar,
                mScope: scope,
                mElement: channel
            )
            var chanWritable: DarwinBoolean = false
            status = AudioObjectIsPropertySettable(deviceID, &chanAddress, &chanWritable)
            if status == noErr && chanWritable.boolValue {
                var volume: Float = 1.0
                let size = UInt32(MemoryLayout<Float>.size)
                _ = AudioObjectSetPropertyData(
                    deviceID,
                    &chanAddress,
                    0,
                    nil,
                    size,
                    &volume
                )
            }
        }
    }
    
    private func getDeviceVolume(_ deviceID: AudioDeviceID, isInput: Bool) -> Float {
        let scope = isInput ? kAudioObjectPropertyScopeInput : kAudioObjectPropertyScopeOutput
        var propertyAddress = AudioObjectPropertyAddress(
            mSelector: kAudioDevicePropertyVolumeScalar,
            mScope: scope,
            mElement: kAudioObjectPropertyElementMain
        )
        
        var volume: Float = 1.0
        var size = UInt32(MemoryLayout<Float>.size)
        let status = AudioObjectGetPropertyData(
            deviceID,
            &propertyAddress,
            0,
            nil,
            &size,
            &volume
        )
        if status == noErr {
            return volume
        }
        
        // Fallback: try channel 1 volume
        var chanAddress = AudioObjectPropertyAddress(
            mSelector: kAudioDevicePropertyVolumeScalar,
            mScope: scope,
            mElement: 1
        )
        var chanVolume: Float = 1.0
        var chanSize = UInt32(MemoryLayout<Float>.size)
        let chanStatus = AudioObjectGetPropertyData(
            deviceID,
            &chanAddress,
            0,
            nil,
            &chanSize,
            &chanVolume
        )
        return chanStatus == noErr ? chanVolume : 1.0
    }
    
    private func setupStateSubscriptions() {
        $bands
            .sink { [weak self] _ in
                DispatchQueue.main.async {
                    self?.updateEQBands()
                }
            }
            .store(in: &cancellables)
            
        $bypass
            .sink { [weak self] bypassed in
                self?.eqNode.bypass = bypassed
                self?.rtBypass = bypassed
            }
            .store(in: &cancellables)
            
        $preamp
            .sink { [weak self] preampVal in
                self?.rtPreamp = Float(preampVal)
            }
            .store(in: &cancellables)
            
        $balance
            .sink { [weak self] balanceVal in
                self?.rtBalance = Float(balanceVal)
            }
            .store(in: &cancellables)
            
        $channelSwap
            .sink { [weak self] swap in
                self?.rtChannelSwap = swap
            }
            .store(in: &cancellables)
            
        $selectedInputDevice
            .sink { [weak self] _ in
                guard let self = self else { return }
                if self.isRunning {
                    DispatchQueue.main.async {
                        self.restart()
                    }
                }
            }
            .store(in: &cancellables)
            
        $selectedOutputDevice
            .sink { [weak self] _ in
                guard let self = self else { return }
                if self.isRunning {
                    DispatchQueue.main.async {
                        self.restart()
                    }
                }
            }
            .store(in: &cancellables)
    }
    
    private func softClip(_ x: Float) -> Float {
        let limit: Float = 0.9
        let absX = abs(x)
        if absX <= limit {
            return x
        } else {
            let sign: Float = x > 0.0 ? 1.0 : -1.0
            let excess = absX - limit
            return sign * (limit + (1.0 - limit) * tanh(excess / (1.0 - limit)))
        }
    }
}

public class AudioLevelMonitor: ObservableObject {
    @Published public var levelLeft: Float = 0.0
    @Published public var levelRight: Float = 0.0
    
    public init() {}
}

