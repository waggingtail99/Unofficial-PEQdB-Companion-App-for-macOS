import Foundation
import os

public final class AudioRingBuffer {
    private var bufferLeft: [Float]
    private var bufferRight: [Float]
    private let capacity: Int
    private var writeIndex = 0
    private var readIndex = 0
    private var lock = os_unfair_lock_s()
    
    public init(capacity: Int = 48000) { // Default capacity of 1 second at 48kHz
        self.capacity = capacity
        self.bufferLeft = [Float](repeating: 0, count: capacity)
        self.bufferRight = [Float](repeating: 0, count: capacity)
    }
    
    public func write(left: UnsafePointer<Float>, right: UnsafePointer<Float>, count: Int) {
        os_unfair_lock_lock(&lock)
        defer { os_unfair_lock_unlock(&lock) }
        
        for i in 0..<count {
            let idx = (writeIndex + i) % capacity
            bufferLeft[idx] = left[i]
            bufferRight[idx] = right[i]
        }
        writeIndex = (writeIndex + count) % capacity
    }
    
    public func read(left: UnsafeMutablePointer<Float>, right: UnsafeMutablePointer<Float>, count: Int) -> Int {
        os_unfair_lock_lock(&lock)
        defer { os_unfair_lock_unlock(&lock) }
        
        let available = (writeIndex >= readIndex) ? (writeIndex - readIndex) : (capacity - readIndex + writeIndex)
        let toRead = min(count, available)
        
        for i in 0..<toRead {
            let idx = (readIndex + i) % capacity
            left[i] = bufferLeft[idx]
            right[i] = bufferRight[idx]
        }
        readIndex = (readIndex + toRead) % capacity
        
        // Zero out the remaining requested buffer if not enough data
        if toRead < count {
            for i in toRead..<count {
                left[i] = 0
                right[i] = 0
            }
        }
        
        return toRead
    }
    
    public func clear() {
        os_unfair_lock_lock(&lock)
        writeIndex = 0
        readIndex = 0
        bufferLeft = [Float](repeating: 0, count: capacity)
        bufferRight = [Float](repeating: 0, count: capacity)
        os_unfair_lock_unlock(&lock)
    }
    
    public var availableSamples: Int {
        os_unfair_lock_lock(&lock)
        defer { os_unfair_lock_unlock(&lock) }
        return (writeIndex >= readIndex) ? (writeIndex - readIndex) : (capacity - readIndex + writeIndex)
    }
    
    public func readLatest(left: UnsafeMutablePointer<Float>, count: Int) {
        os_unfair_lock_lock(&lock)
        defer { os_unfair_lock_unlock(&lock) }
        
        let startIdx = (writeIndex - count + capacity) % capacity
        for i in 0..<count {
            let idx = (startIdx + i) % capacity
            left[i] = bufferLeft[idx]
        }
    }
}
