import Foundation
import Accelerate

public class FFTAnalyzer {
    private let fftSize = 512
    private let log2n: vDSP_Length
    private let fftSetup: FFTSetup
    private var dspSplitComplex: DSPSplitComplex
    private var window: [Float]
    
    // Reusable buffers to prevent heap allocations during real-time processing
    private var windowedInput: [Float]
    private var magnitudes: [Float]
    private var normalizedMags: [Float]
    private var dbValues: [Float]
    private var bins: [Float]
    
    public init() {
        self.log2n = vDSP_Length(log2(Double(fftSize)))
        self.fftSetup = vDSP_create_fftsetup(log2n, FFTRadix(kFFTRadix2))!
        
        let real = UnsafeMutablePointer<Float>.allocate(capacity: fftSize / 2)
        let imag = UnsafeMutablePointer<Float>.allocate(capacity: fftSize / 2)
        self.dspSplitComplex = DSPSplitComplex(realp: real, imagp: imag)
        
        self.window = [Float](repeating: 0.0, count: fftSize)
        vDSP_hann_window(&window, vDSP_Length(fftSize), Int32(vDSP_HANN_NORM))
        
        // Pre-allocate analysis buffers
        self.windowedInput = [Float](repeating: 0.0, count: fftSize)
        self.magnitudes = [Float](repeating: 0.0, count: fftSize / 2)
        self.normalizedMags = [Float](repeating: 0.0, count: fftSize / 2)
        self.dbValues = [Float](repeating: -80.0, count: fftSize / 2)
        self.bins = [Float](repeating: -80.0, count: 32)
    }
    
    deinit {
        vDSP_destroy_fftsetup(fftSetup)
        dspSplitComplex.realp.deallocate()
        dspSplitComplex.imagp.deallocate()
    }
    
    public func analyze(buffer: UnsafePointer<Float>, count: Int, sampleRate: Double) -> [Float] {
        guard count >= fftSize else { return Array(repeating: -80.0, count: 32) }
        
        // 1. Apply Window function
        vDSP_vmul(buffer, 1, window, 1, &windowedInput, 1, vDSP_Length(fftSize))
        
        // 2. Pack real values into split complex structure
        windowedInput.withUnsafeBytes { (rawPtr) in
            let floatPtr = rawPtr.baseAddress!.assumingMemoryBound(to: Float.self)
            vDSP_ctoz(UnsafePointer<DSPComplex>(OpaquePointer(floatPtr)), 2, &dspSplitComplex, 1, vDSP_Length(fftSize / 2))
        }
        
        // 3. Perform forward FFT
        vDSP_fft_zrip(fftSetup, &dspSplitComplex, 1, log2n, FFTDirection(FFT_FORWARD))
        
        // 4. Calculate magnitudes square
        vDSP_zvmags(&dspSplitComplex, 1, &magnitudes, 1, vDSP_Length(fftSize / 2))
        
        // Normalize magnitudes (divide by fftSize * 2)
        var scale = Float(1.0 / Float(fftSize * 2))
        vDSP_vsmul(magnitudes, 1, &scale, &normalizedMags, 1, vDSP_Length(fftSize / 2))
        
        // Convert to dB values
        for i in 0..<(fftSize / 2) {
            let val = normalizedMags[i]
            if val > 1e-8 {
                dbValues[i] = 10.0 * log10(val)
            } else {
                dbValues[i] = -80.0
            }
        }
        
        // 5. Downsample to 32 logarithmic bins
        let numBins = 32
        for binIdx in 0..<numBins {
            let minBinFreq = 20.0 * pow(1000.0, Double(binIdx) / Double(numBins))
            let maxBinFreq = 20.0 * pow(1000.0, Double(binIdx + 1) / Double(numBins))
            
            // Map bin frequencies to FFT indexes
            let startIdx = max(0, min(fftSize / 2 - 1, Int(minBinFreq * Double(fftSize) / sampleRate)))
            let endIdx = max(startIdx, min(fftSize / 2 - 1, Int(maxBinFreq * Double(fftSize) / sampleRate)))
            
            var maxVal: Float = -120.0
            for fftIdx in startIdx...endIdx {
                let val = dbValues[fftIdx]
                if val > maxVal {
                    maxVal = val
                }
            }
            bins[binIdx] = maxVal > -120.0 ? maxVal : -80.0
        }
        
        return bins
    }
}
