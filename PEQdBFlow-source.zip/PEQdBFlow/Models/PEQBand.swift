import Foundation

public enum EQType: String, Codable, CaseIterable {
    case peak = "PK"
    case lowShelf = "LSC"
    case highShelf = "HSC"
    case lowPass = "LP"
    case highPass = "HP"
    
    public var displayName: String {
        switch self {
        case .peak: return "Peaking"
        case .lowShelf: return "Low Shelf"
        case .highShelf: return "High Shelf"
        case .lowPass: return "Low Pass"
        case .highPass: return "High Pass"
        }
    }
}

public struct PEQBand: Identifiable, Codable, Equatable {
    public var id = UUID()
    public var isEnabled: Bool = true
    public var frequency: Double // Hz
    public var gain: Double     // dB
    public var q: Double        // Quality factor
    public var type: EQType
    
    public init(id: UUID = UUID(), isEnabled: Bool = true, frequency: Double, gain: Double, q: Double, type: EQType) {
        self.id = id
        self.isEnabled = isEnabled
        self.frequency = frequency
        self.gain = gain
        self.q = q
        self.type = type
    }
    
    // Calculates biquad coefficients based on Robert Bristow-Johnson's audio EQ cookbook formulas.
    // sampleRate is typically 48000.0 or 44100.0 Hz.
    public func biquadCoefficients(sampleRate: Double = 48000.0) -> (b0: Double, b1: Double, b2: Double, a0: Double, a1: Double, a2: Double) {
        let sr = sampleRate > 0.0 ? sampleRate : 48000.0
        let clampedQ = max(0.01, q)
        let clampedFreq = max(10.0, min(frequency, sr / 2.0 - 50.0))
        let w0 = 2.0 * Double.pi * clampedFreq / sr
        let cosW0 = cos(w0)
        let sinW0 = sin(w0)
        let alpha = sinW0 / (2.0 * clampedQ)
        
        switch type {
        case .peak:
            let A = pow(10.0, gain / 40.0)
            let b0 = 1.0 + alpha * A
            let b1 = -2.0 * cosW0
            let b2 = 1.0 - alpha * A
            let a0 = 1.0 + alpha / A
            let a1 = -2.0 * cosW0
            let a2 = 1.0 - alpha / A
            return (b0, b1, b2, a0, a1, a2)
            
        case .lowShelf:
            let A = pow(10.0, gain / 40.0)
            let beta = sqrt(A) * (sinW0 / q) // simple shelf mapping
            let b0 = A * ((A + 1.0) - (A - 1.0) * cosW0 + beta)
            let b1 = 2.0 * A * ((A - 1.0) - (A + 1.0) * cosW0)
            let b2 = A * ((A + 1.0) - (A - 1.0) * cosW0 - beta)
            let a0 = (A + 1.0) + (A - 1.0) * cosW0 + beta
            let a1 = -2.0 * ((A - 1.0) + (A + 1.0) * cosW0)
            let a2 = (A + 1.0) + (A - 1.0) * cosW0 - beta
            return (b0, b1, b2, a0, a1, a2)
            
        case .highShelf:
            let A = pow(10.0, gain / 40.0)
            let beta = sqrt(A) * (sinW0 / q)
            let b0 = A * ((A + 1.0) + (A - 1.0) * cosW0 + beta)
            let b1 = -2.0 * A * ((A - 1.0) + (A + 1.0) * cosW0)
            let b2 = A * ((A + 1.0) + (A - 1.0) * cosW0 - beta)
            let a0 = (A + 1.0) - (A - 1.0) * cosW0 + beta
            let a1 = 2.0 * ((A - 1.0) - (A + 1.0) * cosW0)
            let a2 = (A + 1.0) - (A - 1.0) * cosW0 - beta
            return (b0, b1, b2, a0, a1, a2)
            
        case .lowPass:
            let b0 = (1.0 - cosW0) / 2.0
            let b1 = 1.0 - cosW0
            let b2 = (1.0 - cosW0) / 2.0
            let a0 = 1.0 + alpha
            let a1 = -2.0 * cosW0
            let a2 = 1.0 - alpha
            return (b0, b1, b2, a0, a1, a2)
            
        case .highPass:
            let b0 = (1.0 + cosW0) / 2.0
            let b1 = -(1.0 + cosW0)
            let b2 = (1.0 + cosW0) / 2.0
            let a0 = 1.0 + alpha
            let a1 = -2.0 * cosW0
            let a2 = 1.0 - alpha
            return (b0, b1, b2, a0, a1, a2)
        }
    }
    
    // Calculates the decibel gain of this specific band at a target frequency.
    public func magnitudeAt(frequency f: Double, sampleRate: Double = 48000.0) -> Double {
        guard isEnabled else { return 0.0 }
        
        let sr = sampleRate > 0.0 ? sampleRate : 48000.0
        let coefs = biquadCoefficients(sampleRate: sr)
        let w = 2.0 * Double.pi * f / sr
        let cosW = cos(w)
        let sinW = sin(w)
        let cos2W = cos(2.0 * w)
        let sin2W = sin(2.0 * w)
        
        // Numerator
        let numReal = coefs.b0 + coefs.b1 * cosW + coefs.b2 * cos2W
        let numImag = -(coefs.b1 * sinW + coefs.b2 * sin2W)
        let numMagSq = numReal * numReal + numImag * numImag
        
        // Denominator
        let denReal = coefs.a0 + coefs.a1 * cosW + coefs.a2 * cos2W
        let denImag = -(coefs.a1 * sinW + coefs.a2 * sin2W)
        let denMagSq = denReal * denReal + denImag * denImag
        
        if denMagSq == 0.0 { return 0.0 }
        
        let ratio = numMagSq / denMagSq
        if ratio <= 0.0 { return -100.0 }
        
        return 10.0 * log10(ratio)
    }
}
