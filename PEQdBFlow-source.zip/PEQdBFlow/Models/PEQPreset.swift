import Foundation

public struct PEQPreset: Identifiable, Codable, Equatable {
    public var id = UUID()
    public var name: String
    public var preamp: Double // dB (usually negative to avoid clipping)
    public var balance: Double // -1.0 (Left) to 1.0 (Right)
    public var bands: [PEQBand]
    
    public init(id: UUID = UUID(), name: String, preamp: Double = 0.0, balance: Double = 0.0, bands: [PEQBand]) {
        self.id = id
        self.name = name
        self.preamp = preamp
        self.balance = balance
        self.bands = bands
    }
    
    // Calculates the combined frequency response in dB at a target frequency
    public func combinedMagnitudeAt(frequency f: Double, sampleRate: Double = 48000.0) -> Double {
        var totalGain = preamp
        for band in bands {
            totalGain += band.magnitudeAt(frequency: f, sampleRate: sampleRate)
        }
        return totalGain
    }
    
    // Bundled standard presets
    public static var defaultPresets: [PEQPreset] {
        return [
            PEQPreset(
                name: "AKG EO-IG955 (Qudelix/T71 Downmix Setup)",
                preamp: -17.4,
                balance: 0.0,
                bands: [
                    PEQBand(frequency: 29, gain: -0.21, q: 1.746, type: .lowShelf),
                    PEQBand(frequency: 34, gain: -1.35, q: 0.905, type: .peak),
                    PEQBand(frequency: 75, gain: -4.93, q: 0.415, type: .peak),
                    PEQBand(frequency: 105, gain: 17.43, q: 0.600, type: .lowShelf),
                    PEQBand(frequency: 661, gain: 0.57, q: 1.279, type: .highShelf),
                    PEQBand(frequency: 723, gain: 6.80, q: 0.601, type: .peak),
                    PEQBand(frequency: 1976, gain: 2.54, q: 0.844, type: .peak),
                    PEQBand(frequency: 2569, gain: 3.53, q: 1.860, type: .peak),
                    PEQBand(frequency: 2619, gain: -3.95, q: 1.200, type: .peak),
                    PEQBand(frequency: 3086, gain: 4.40, q: 0.700, type: .highShelf),
                    PEQBand(frequency: 4418, gain: 4.50, q: 1.763, type: .peak),
                    PEQBand(frequency: 5792, gain: 2.14, q: 1.449, type: .peak),
                    PEQBand(frequency: 9848, gain: 3.15, q: 0.831, type: .peak),
                    PEQBand(frequency: 14154, gain: -3.30, q: 1.028, type: .peak),
                    PEQBand(frequency: 15605, gain: 4.16, q: 0.489, type: .peak)
                ]
            ),
            PEQPreset(
                name: "AKG EO-IG955 (SpinFit W1 - Harman Ref)",
                preamp: -4.5,
                balance: 0.0,
                bands: [
                    PEQBand(frequency: 45, gain: 3.5, q: 0.7, type: .lowShelf),
                    PEQBand(frequency: 110, gain: -1.8, q: 1.2, type: .peak),
                    PEQBand(frequency: 240, gain: -1.0, q: 1.5, type: .peak),
                    PEQBand(frequency: 710, gain: 1.5, q: 1.1, type: .peak),
                    PEQBand(frequency: 1600, gain: -2.0, q: 2.0, type: .peak),
                    PEQBand(frequency: 3000, gain: 3.0, q: 1.8, type: .peak),
                    PEQBand(frequency: 4800, gain: -4.5, q: 2.5, type: .peak),
                    PEQBand(frequency: 7200, gain: 2.0, q: 2.0, type: .peak),
                    PEQBand(frequency: 10000, gain: -3.0, q: 1.5, type: .peak),
                    PEQBand(frequency: 13000, gain: 1.5, q: 0.7, type: .highShelf)
                ]
            ),
            PEQPreset(
                name: "AKG EO-IG955 (Warm Bass & Punch)",
                preamp: -6.0,
                balance: 0.0,
                bands: [
                    PEQBand(frequency: 60, gain: 5.5, q: 0.6, type: .lowShelf),
                    PEQBand(frequency: 150, gain: -1.0, q: 1.0, type: .peak),
                    PEQBand(frequency: 600, gain: 1.0, q: 1.0, type: .peak),
                    PEQBand(frequency: 2000, gain: 1.5, q: 1.5, type: .peak),
                    PEQBand(frequency: 4800, gain: -5.0, q: 2.5, type: .peak),
                    PEQBand(frequency: 8000, gain: 3.0, q: 2.0, type: .peak)
                ]
            ),
            PEQPreset(
                name: "Vibe Flat (Bypass EQ)",
                preamp: 0.0,
                balance: 0.0,
                bands: (1...10).map { i in
                    PEQBand(frequency: Double(i * 1000), gain: 0.0, q: 1.0, type: .peak)
                }
            ),
            PEQPreset(
                name: "Treble Defuser (Anti-Sibilance)",
                preamp: -2.0,
                balance: 0.0,
                bands: [
                    PEQBand(frequency: 3000, gain: -1.5, q: 1.5, type: .peak),
                    PEQBand(frequency: 4800, gain: -6.0, q: 3.0, type: .peak),
                    PEQBand(frequency: 7000, gain: -3.0, q: 2.0, type: .peak),
                    PEQBand(frequency: 10000, gain: -2.0, q: 1.5, type: .peak)
                ]
            )
        ]
    }
}
