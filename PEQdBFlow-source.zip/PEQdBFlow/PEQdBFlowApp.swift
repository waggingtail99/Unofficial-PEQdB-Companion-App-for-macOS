import SwiftUI
import AppKit

@main
struct PEQdBFlowApp: App {
    @StateObject private var audioEngine = AudioEngineManager()
    
    init() {
        let showDockIcon = UserDefaults.standard.object(forKey: "com.vibe.peqdbflow.showDockIcon") as? Bool ?? true
        DispatchQueue.main.async {
            if showDockIcon {
                NSApp.setActivationPolicy(.regular)
            } else {
                NSApp.setActivationPolicy(.accessory)
            }
        }
    }
    
    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(audioEngine)
                .navigationTitle("PEQdB Flow")
        }
        .windowStyle(.hiddenTitleBar)
        
        MenuBarExtra("PEQdB Flow", systemImage: "waveform.path") {
            Button(audioEngine.isRunning ? "Stop EQ Processing" : "Start EQ Processing") {
                if audioEngine.isRunning {
                    audioEngine.stop()
                } else {
                    audioEngine.start()
                }
            }
            
            Button(audioEngine.bypass ? "Enforce EQ" : "Bypass EQ") {
                audioEngine.bypass.toggle()
            }
            .keyboardShortcut("B", modifiers: [.command, .shift])
            
            Divider()
            
            Button("Open Control Panel") {
                NSApp.activate(ignoringOtherApps: true)
                if let window = NSApp.windows.first(where: { !$0.title.isEmpty }) {
                    window.makeKeyAndOrderFront(nil)
                }
            }
            
            Divider()
            
            Button("Quit PEQdB Flow") {
                audioEngine.stop()
                NSApplication.shared.terminate(nil)
            }
            .keyboardShortcut("q", modifiers: [.command])
        }
    }
}
