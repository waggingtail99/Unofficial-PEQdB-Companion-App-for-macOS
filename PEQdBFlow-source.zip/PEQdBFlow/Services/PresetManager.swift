import Foundation
import Combine

public class PresetManager: ObservableObject {
    @Published public var presets: [PEQPreset] = []
    
    private let presetsKey = "com.vibe.peqdbflow.presets"
    
    public init() {
        loadPresets()
    }
    
    public func loadPresets() {
        if let data = UserDefaults.standard.data(forKey: presetsKey) {
            do {
                presets = try JSONDecoder().decode([PEQPreset].self, from: data)
            } catch {
                print("Failed to decode presets: \(error)")
                loadDefaults()
            }
        } else {
            loadDefaults()
        }
    }
    
    public func savePresets() {
        do {
            let data = try JSONEncoder().encode(presets)
            UserDefaults.standard.set(data, forKey: presetsKey)
        } catch {
            print("Failed to encode and save presets: \(error)")
        }
    }
    
    private func loadDefaults() {
        presets = PEQPreset.defaultPresets
        savePresets()
    }
    
    public func addPreset(_ preset: PEQPreset) {
        presets.append(preset)
        savePresets()
    }
    
    public func updatePreset(_ preset: PEQPreset) {
        if let index = presets.firstIndex(where: { $0.id == preset.id }) {
            presets[index] = preset
            savePresets()
        }
    }
    
    public func deletePreset(at indexSet: IndexSet) {
        presets.remove(atOffsets: indexSet)
        savePresets()
    }
    
    public func deletePreset(_ preset: PEQPreset) {
        presets.removeAll(where: { $0.id == preset.id })
        savePresets()
    }
    
    // MARK: - Equalizer APO Parser
    public func parseEqualizerAPO(_ text: String, name: String) -> PEQPreset? {
        var preamp: Double = 0.0
        var bands: [PEQBand] = []
        
        let lines = text.components(separatedBy: .newlines)
        for line in lines {
            let trimmed = line.trimmingCharacters(in: .whitespacesAndNewlines)
            if trimmed.isEmpty || trimmed.hasPrefix("#") { continue }
            
            // Check for Preamp setting
            if trimmed.lowercased().hasPrefix("preamp:") {
                let parts = trimmed.components(separatedBy: .whitespaces)
                if parts.count >= 2 {
                    let valStr = parts[1].replacingOccurrences(of: "dB", with: "", options: .caseInsensitive)
                        .trimmingCharacters(in: .whitespaces)
                    if let val = Double(valStr) {
                        preamp = val
                    }
                }
                continue
            }
            
            // Check for Filter band settings
            // Format: "Filter 1: ON PK Fc 20 Hz Gain -1.3 dB Q 2.0"
            if trimmed.lowercased().contains("filter") {
                let lowerLine = trimmed.lowercased()
                
                // Extract filter type
                var filterType: EQType = .peak
                if lowerLine.contains(" pk ") {
                    filterType = .peak
                } else if lowerLine.contains(" lsc ") {
                    filterType = .lowShelf
                } else if lowerLine.contains(" hsc ") {
                    filterType = .highShelf
                } else if lowerLine.contains(" lp ") {
                    filterType = .lowPass
                } else if lowerLine.contains(" hp ") {
                    filterType = .highPass
                }
                
                // Extract Frequency
                var freq: Double = 1000.0
                if let fcRange = lowerLine.range(of: "fc ") {
                    let afterFc = trimmed[fcRange.upperBound...]
                    let tokens = afterFc.components(separatedBy: .whitespaces)
                    if let first = tokens.first {
                        let cleanFreq = first.replacingOccurrences(of: "hz", with: "", options: .caseInsensitive)
                        if let val = Double(cleanFreq) {
                            freq = val
                        }
                    }
                }
                
                // Extract Gain
                var gain: Double = 0.0
                if let gainRange = lowerLine.range(of: "gain ") {
                    let afterGain = trimmed[gainRange.upperBound...]
                    let tokens = afterGain.components(separatedBy: .whitespaces)
                    if let first = tokens.first {
                        let cleanGain = first.replacingOccurrences(of: "db", with: "", options: .caseInsensitive)
                        if let val = Double(cleanGain) {
                            gain = val
                        }
                    }
                }
                
                // Extract Q Factor
                var qVal: Double = 1.0
                if let qRange = lowerLine.range(of: " q ") {
                    let afterQ = trimmed[qRange.upperBound...]
                    let tokens = afterQ.components(separatedBy: .whitespaces)
                    if let first = tokens.first {
                        if let val = Double(first) {
                            qVal = val
                        }
                    }
                }
                
                let isEnabled = !lowerLine.contains(" off ")
                
                bands.append(PEQBand(
                    isEnabled: isEnabled,
                    frequency: freq,
                    gain: gain,
                    q: qVal,
                    type: filterType
                ))
            }
        }
        
        if bands.isEmpty { return nil }
        return PEQPreset(name: name, preamp: preamp, bands: bands)
    }
    
    // MARK: - Remote Preset Downloader
    public func fetchPresetFromURL(_ url: URL, completion: @escaping (PEQPreset?) -> Void) {
        let task = URLSession.shared.dataTask(with: url) { [weak self] data, response, error in
            guard error == nil, let data = data else {
                DispatchQueue.main.async { completion(nil) }
                return
            }
            
            if let text = String(data: data, encoding: .utf8) {
                // Determine a nice default name based on file/domain name
                var defaultName = "Downloaded EQ"
                if url.pathComponents.count > 1 {
                    let fileName = url.lastPathComponent.replacingOccurrences(of: "%20", with: " ")
                    defaultName = fileName.replacingOccurrences(of: "ParametricEQ.txt", with: "")
                        .replacingOccurrences(of: ".txt", with: "")
                        .trimmingCharacters(in: .whitespacesAndNewlines)
                }
                
                let parsed = self?.parseEqualizerAPO(text, name: defaultName)
                DispatchQueue.main.async { completion(parsed) }
            } else {
                DispatchQueue.main.async { completion(nil) }
            }
        }
        task.resume()
    }
    
    public func exportToEqualizerAPO(preset: PEQPreset) -> String {
        var lines = [
            "# PEQdB Flow Preset Export",
            "# Name: \(preset.name)",
            "Preamp: \(String(format: "%.1f", preset.preamp)) dB"
        ]
        for (index, band) in preset.bands.enumerated() {
            let status = band.isEnabled ? "ON" : "OFF"
            let typeStr = band.type.rawValue
            let freqStr = String(format: "%.0f", band.frequency)
            let gainStr = String(format: "%.1f", band.gain)
            let qStr = String(format: "%.3f", band.q)
            lines.append("Filter \(index + 1): \(status) \(typeStr) Fc \(freqStr) Hz Gain \(gainStr) dB Q \(qStr)")
        }
        return lines.joined(separator: "\n")
    }
}
