import SwiftUI
import CoreAudio
import Foundation
import AppKit

public struct ContentView: View {
    @EnvironmentObject private var audioEngine: AudioEngineManager
    @StateObject private var presetManager = PresetManager()
    
    @State private var selectedPresetID: UUID? = nil
    
    // Import state variables
    @State private var importURLString = ""
    @State private var importPasteText = ""
    @State private var showImportSheet = false
    @State private var showPasteSheet = false
    @State private var importError = ""
    
    // Rename state
    @State private var renamingPresetID: UUID? = nil
    @State private var renamingText = ""
    @FocusState private var isTextFieldFocused: Bool
    
    // Settings state
    @AppStorage("com.vibe.peqdbflow.theme") private var selectedTheme = "Dark"
    @AppStorage("com.vibe.peqdbflow.autoStartLoopback") private var autoStartLoopback = false
    @State private var showSettingsSheet = false
    
    // Tab selection state
    @State private var selectedTab = 0
    
    private var isClippingRisk: Bool {
        let maxBoost = audioEngine.bands.filter { $0.isEnabled }.map { $0.gain }.max() ?? 0.0
        return (audioEngine.preamp + maxBoost) > 0.0
    }
    
    private var suggestedPreamp: Double {
        let maxBoost = audioEngine.bands.filter { $0.isEnabled }.map { $0.gain }.max() ?? 0.0
        return -maxBoost
    }
    
    // No local session timer needed (isolated to SessionStatsView)
    
    public var body: some View {
        HStack(spacing: 0) {
            // Left Control Sidebar (Translucent Sidebar)
            sidebarView
                .frame(width: 280)
                .background(VisualEffectView(material: .sidebar, blendingMode: .behindWindow))
            
            Divider()
            
            // Right Main Panel
            VStack(spacing: 0) {
                // Core Audio Error Banner
                if let error = audioEngine.lastError {
                    HStack(spacing: 12) {
                        Image(systemName: "exclamationmark.triangle.fill")
                            .foregroundColor(.white)
                            .font(.title3)
                        
                        VStack(alignment: .leading, spacing: 2) {
                            Text("AUDIO CONFIGURATION ERROR")
                                .font(.system(size: 9, weight: .bold))
                                .foregroundColor(.white.opacity(0.8))
                            Text(error)
                                .font(.body)
                                .foregroundColor(.white)
                        }
                        Spacer()
                    }
                    .padding()
                    .background(Color.red.opacity(0.8))
                    .cornerRadius(8)
                    .padding([.top, .horizontal])
                }
                
                // Top Interactive Graph
                graphView
                    .padding()
                
                Divider()
                
                // Bottom tab panel control
                Picker("", selection: $selectedTab) {
                    Text("EQ Bands").tag(0)
                    Text("Audio Routing").tag(1)
                    Text("Volume & System").tag(2)
                }
                .pickerStyle(.segmented)
                .padding([.horizontal, .top])
                
                Group {
                    if selectedTab == 0 {
                        bandEditorList
                    } else if selectedTab == 1 {
                        audioRoutingPanel
                    } else {
                        volumeAndMeteringPanel
                    }
                }
                .padding()
                .frame(maxHeight: 280)
            }
            .background(VisualEffectView(material: .contentBackground, blendingMode: .behindWindow))
        }
        .frame(minWidth: 1000, minHeight: 700)
        .preferredColorScheme(selectedTheme == "Dark" ? .dark : selectedTheme == "Light" ? .light : nil)
        .onAppear {
            initializePresetSelection()
            if autoStartLoopback {
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                    if !audioEngine.isRunning {
                        audioEngine.start()
                    }
                }
            }
        }
        .onChange(of: selectedPresetID) {
            applyPresetToEngine(selectedPresetID)
        }
        .onChange(of: audioEngine.bands) {
            audioEngine.updateEQBands()
            saveActivePresetChanges()
        }
        .onChange(of: audioEngine.preamp) {
            saveActivePresetChanges()
        }
        .onChange(of: audioEngine.balance) {
            saveActivePresetChanges()
        }
        .sheet(isPresented: $showImportSheet) {
            importURLSheet
        }
        .sheet(isPresented: $showPasteSheet) {
            importPasteSheet
        }
        .sheet(isPresented: $showSettingsSheet) {
            SettingsView()
        }
        // Keyboard Shortcut Observers
        .background(
            ZStack {
                Button("") {
                    audioEngine.bypass.toggle()
                }
                .keyboardShortcut(.space, modifiers: [])
                .opacity(0)
                .frame(width: 0, height: 0)
                
                Button("") {
                    importError = ""
                    importPasteText = ""
                    showPasteSheet = true
                }
                .keyboardShortcut("t", modifiers: [.command])
                .opacity(0)
                .frame(width: 0, height: 0)
            }
        )
    }
    
    // MARK: - Subviews
    
    private var graphView: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                VStack(alignment: .leading) {
                    Text("FREQUENCY RESPONSE")
                        .font(.system(size: 10, weight: .bold))
                        .foregroundColor(.secondary)
                    Text("AKG EO-IG955 Correction Curve")
                        .font(.title3)
                        .fontWeight(.semibold)
                }
                
                Spacer()
                
                HStack(spacing: 12) {
                    legendItem(color: Color.red.opacity(0.5), label: "AKG Raw", isDashed: true)
                    legendItem(color: Color.purple, label: "EQ Filter", isDashed: false)
                    legendItem(color: Color(red: 0.1, green: 0.8, blue: 0.8), label: "Corrected Target", isDashed: false)
                }
            }
            
            InteractiveChartView(
                bands: $audioEngine.bands,
                preamp: $audioEngine.preamp,
                sampleRate: audioEngine.sampleRate,
                spectrumPublisher: audioEngine.spectrumPublisher,
                initialSpectrum: audioEngine.spectrum
            )
            .frame(height: 280)
        }
    }
    
    private var sidebarView: some View {
        VStack(alignment: .leading, spacing: 20) {
            HStack(spacing: 10) {
                Image(systemName: "waveform.path")
                    .font(.title2)
                    .foregroundColor(.purple)
                Text("PEQdB Flow")
                    .font(.title2)
                    .fontWeight(.bold)
                
                Spacer()
                
                Button(action: {
                    showSettingsSheet = true
                }) {
                    Image(systemName: "gearshape")
                        .font(.title3)
                        .foregroundColor(.primary.opacity(0.7))
                }
                .buttonStyle(.plain)
                .help("Settings")
            }
            .padding(.top, 24)
            .padding(.horizontal)
            
            VStack(alignment: .leading, spacing: 10) {
                HStack {
                    Text("PEQ PRESETS")
                        .font(.system(size: 10, weight: .bold))
                        .foregroundColor(.secondary)
                    
                    Spacer()
                    
                    Menu {
                        Button("Import from URL") {
                            importError = ""
                            importURLString = ""
                            showImportSheet = true
                        }
                        Button("Paste ParametricEQ.txt") {
                            importError = ""
                            importPasteText = ""
                            showPasteSheet = true
                        }
                        .keyboardShortcut("t", modifiers: [.command])
                    } label: {
                        Image(systemName: "plus")
                            .foregroundColor(.purple)
                    }
                    .menuStyle(.borderlessButton)
                    .frame(width: 24)
                }
                
                ScrollView {
                    VStack(spacing: 6) {
                        ForEach(presetManager.presets) { preset in
                            let isSelected = selectedPresetID == preset.id
                            HStack {
                                Image(systemName: isSelected ? "checkmark.circle.fill" : "circle")
                                    .foregroundColor(isSelected ? .purple : .secondary)
                                
                                if renamingPresetID == preset.id {
                                    TextField("", text: $renamingText)
                                        .focused($isTextFieldFocused)
                                        .textFieldStyle(.plain)
                                        .font(.body)
                                        .foregroundColor(.primary)
                                        .frame(maxWidth: 130)
                                        .onSubmit {
                                            saveRename(preset: preset)
                                        }
                                } else {
                                    Text(preset.name)
                                        .font(.body)
                                        .lineLimit(1)
                                        .foregroundColor(isSelected ? .primary : .primary.opacity(0.8))
                                        .overlay(
                                            Group {
                                                if !PEQPreset.defaultPresets.map({ $0.name }).contains(preset.name) {
                                                    ForceTouchView(onForceTouch: {
                                                        renamingText = preset.name
                                                        renamingPresetID = preset.id
                                                        isTextFieldFocused = true
                                                    }, onTap: {
                                                        selectedPresetID = preset.id
                                                    })
                                                }
                                            }
                                        )
                                }
                                
                                Spacer()
                                
                                if isSelected {
                                    Button(action: {
                                        let text = presetManager.exportToEqualizerAPO(preset: preset)
                                        NSPasteboard.general.clearContents()
                                        NSPasteboard.general.setString(text, forType: .string)
                                    }) {
                                        Image(systemName: "doc.on.doc")
                                            .font(.caption)
                                            .foregroundColor(.purple.opacity(0.8))
                                    }
                                    .buttonStyle(.plain)
                                    .help("Copy APO Text")
                                    
                                    Button(action: {
                                        exportPresetFile(preset: preset)
                                    }) {
                                        Image(systemName: "square.and.arrow.up")
                                            .font(.caption)
                                            .foregroundColor(.purple.opacity(0.8))
                                    }
                                    .buttonStyle(.plain)
                                    .help("Export File")
                                }
                                
                                if !PEQPreset.defaultPresets.map({ $0.name }).contains(preset.name) {
                                    Button(action: {
                                        presetManager.deletePreset(preset)
                                        initializePresetSelection()
                                    }) {
                                        Image(systemName: "trash")
                                            .font(.caption)
                                            .foregroundColor(.red.opacity(0.6))
                                    }
                                    .buttonStyle(.plain)
                                }
                            }
                            .padding(.vertical, 8)
                            .padding(.horizontal, 10)
                            .background(
                                RoundedRectangle(cornerRadius: 8)
                                    .fill(isSelected ? Color.purple.opacity(0.15) : Color.primary.opacity(0.03))
                            )
                            .overlay(
                                RoundedRectangle(cornerRadius: 8)
                                    .stroke(isSelected ? Color.purple.opacity(0.4) : Color.clear, lineWidth: 1)
                            )
                            .contentShape(Rectangle())
                            .onTapGesture {
                                selectedPresetID = preset.id
                            }
                        }
                    }
                    .padding(.trailing, 2)
                }
                .frame(height: 380)
                .onChange(of: isTextFieldFocused) {
                    if !isTextFieldFocused, let renamingID = renamingPresetID {
                        if let preset = presetManager.presets.first(where: { $0.id == renamingID }) {
                            saveRename(preset: preset)
                        }
                    }
                }
            }
            .padding(.horizontal)
            
            Spacer()
            
            SessionStatsView(audioEngine: audioEngine, selectedPresetID: $selectedPresetID, presetManager: presetManager)
                .padding([.horizontal, .bottom])
        }
    }
    
    private var volumeAndMeteringPanel: some View {
        ScrollView(.vertical, showsIndicators: true) {
            VStack(spacing: 16) {
                // Safety headroom warning
                if isClippingRisk {
                    HStack {
                        Image(systemName: "exclamationmark.triangle.fill")
                            .foregroundColor(.yellow)
                        Text(String(format: "Clipping Risk: EQ boost exceeds preamp headroom. Suggested: %.1f dB", suggestedPreamp))
                            .font(.caption)
                            .foregroundColor(.yellow)
                        Spacer()
                        Button("Auto-Fix") {
                            audioEngine.preamp = suggestedPreamp
                        }
                        .buttonStyle(.bordered)
                        .controlSize(.mini)
                    }
                    .padding(8)
                    .background(Color.yellow.opacity(0.15))
                    .cornerRadius(8)
                }
                
                LazyVGrid(columns: [GridItem(.adaptive(minimum: 285, maximum: 360), spacing: 24)], spacing: 20) {
                    VStack(alignment: .leading, spacing: 12) {
                        Text("SYSTEM VOLUMES")
                            .font(.system(size: 9, weight: .bold))
                            .foregroundColor(.secondary)
                        
                        VStack(alignment: .leading, spacing: 4) {
                            HStack {
                                Text("Pre-Gain Preamp")
                                    .font(.caption)
                                Spacer()
                                Text(String(format: "%.1f dB", audioEngine.preamp))
                                    .font(.system(size: 10, design: .monospaced))
                                    .foregroundColor(.orange)
                            }
                            CustomSlider(value: $audioEngine.preamp, range: -15.0...0.0, activeColor: .orange)
                        }
                        
                        VStack(alignment: .leading, spacing: 4) {
                            HStack {
                                Text("L/R Balance")
                                    .font(.caption)
                                Spacer()
                                Text(String(format: audioEngine.balance < 0 ? "L %.0f%%" : audioEngine.balance > 0 ? "R %.0f%%" : "Center", abs(audioEngine.balance) * 100))
                                    .font(.system(size: 10, design: .monospaced))
                                    .foregroundColor(.blue)
                            }
                            CustomSlider(value: $audioEngine.balance, range: -1.0...1.0, activeColor: .blue)
                        }
                    }
                    
                    VStack(alignment: .leading, spacing: 12) {
                        Text("HARDWARE CONTROLS")
                            .font(.system(size: 9, weight: .bold))
                            .foregroundColor(.secondary)
                        
                        HStack(spacing: 12) {
                            PulsingPlayButton(audioEngine: audioEngine)
                                .frame(width: 130)
                            
                            VStack(spacing: 8) {
                                EQBypassRow(isBypassed: $audioEngine.bypass)
                                    .frame(width: 140)
                                ChannelSwapRow(isSwapped: $audioEngine.channelSwap)
                                    .frame(width: 140)
                            }
                        }
                    }
                    
                    VStack(alignment: .leading, spacing: 12) {
                        Text("REAL-TIME LEVELS")
                            .font(.system(size: 9, weight: .bold))
                            .foregroundColor(.secondary)
                        
                        AudioLevelsView(monitor: audioEngine.levelMonitor)
                            .frame(maxWidth: .infinity)
                    }
                }
            }
            .padding(.trailing, 8)
        }
    }
    
    private var audioRoutingPanel: some View {
        ScrollView(.vertical, showsIndicators: true) {
            LazyVGrid(columns: [GridItem(.adaptive(minimum: 285, maximum: 360), spacing: 24)], spacing: 20) {
                VStack(alignment: .leading, spacing: 12) {
                    Text("INPUT LOOPBACK SOURCE")
                        .font(.system(size: 9, weight: .bold))
                        .foregroundColor(.secondary)
                    
                    Picker("", selection: $audioEngine.selectedInputDevice) {
                        Text("Select Input...").tag(nil as AudioDeviceID?)
                        ForEach(audioEngine.devices.filter { $0.hasInput }, id: \.id) { device in
                            Text("\(device.name)").tag(device.id as AudioDeviceID?)
                        }
                    }
                    .pickerStyle(.menu)
                    .labelsHidden()
                    .frame(maxWidth: .infinity)
                    
                    Text("Route system audio to BlackHole to capture the input stream.")
                        .font(.caption2)
                        .foregroundColor(.secondary)
                        .frame(maxWidth: .infinity, alignment: .leading)
                }
                
                VStack(alignment: .leading, spacing: 12) {
                    Text("PHYSICAL DAC OUTPUT")
                        .font(.system(size: 9, weight: .bold))
                        .foregroundColor(.secondary)
                    
                    Picker("", selection: $audioEngine.selectedOutputDevice) {
                        Text("Select Output...").tag(nil as AudioDeviceID?)
                        ForEach(audioEngine.devices.filter { $0.hasOutput }, id: \.id) { device in
                            Text("\(device.name) (\(device.manufacturer))").tag(device.id as AudioDeviceID?)
                        }
                    }
                    .pickerStyle(.menu)
                    .labelsHidden()
                    .frame(maxWidth: .infinity)
                    
                    Text("Select your output DAC (e.g. Fosi Audio DS2) to output EQ'ed audio.")
                        .font(.caption2)
                        .foregroundColor(.secondary)
                        .frame(maxWidth: .infinity, alignment: .leading)
                }
                
                VStack(alignment: .leading, spacing: 12) {
                    Text("STATUS & SCAN")
                        .font(.system(size: 9, weight: .bold))
                        .foregroundColor(.secondary)
                    
                    HStack(spacing: 8) {
                        Circle()
                            .fill(audioEngine.permissionStatus == "Authorized" ? Color.green : Color.red)
                            .frame(width: 8, height: 8)
                        Text("Mic: \(audioEngine.permissionStatus)")
                            .font(.caption)
                        
                        if audioEngine.permissionStatus != "Authorized" {
                            Button("Grant") {
                                audioEngine.requestPermission { _ in }
                            }
                            .buttonStyle(.bordered)
                            .controlSize(.small)
                        }
                    }
                    
                    Button(action: {
                        audioEngine.refreshDevices()
                    }) {
                        HStack {
                            Image(systemName: "arrow.clockwise")
                            Text("Scan Audio Devices")
                        }
                    }
                    .buttonStyle(.bordered)
                    .controlSize(.small)
                }
            }
            .padding(.trailing, 8)
        }
    }
    
    private var bandEditorList: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack {
                Text("PARAMETRIC EQ BAND SUMMARY")
                    .font(.system(size: 10, weight: .bold))
                    .foregroundColor(.secondary)
                Spacer()
                Text("Click graph nodes to edit precise values")
                    .font(.caption2)
                    .foregroundColor(.secondary.opacity(0.8))
            }
            
            ScrollView {
                LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 8) {
                    ForEach(Array(audioEngine.bands.enumerated()), id: \.element.id) { idx, band in
                        HStack(spacing: 8) {
                            Circle()
                                .fill(band.isEnabled ? Color.purple : Color.secondary.opacity(0.3))
                                .frame(width: 14, height: 14)
                                .overlay(
                                    Text("\(idx + 1)")
                                        .font(.system(size: 7, weight: .bold))
                                        .foregroundColor(.white)
                                )
                            
                            VStack(alignment: .leading, spacing: 2) {
                                Text(band.type.displayName)
                                    .font(.system(size: 10, weight: .semibold))
                                Text("\(Int(band.frequency)) Hz | \(String(format: "%+.1f dB", band.gain)) | Q: \(String(format: "%.2f", band.q))")
                                    .font(.system(size: 9, design: .monospaced))
                                    .foregroundColor(.secondary)
                            }
                            Spacer()
                            
                            Toggle("", isOn: $audioEngine.bands[idx].isEnabled)
                                .toggleStyle(.checkbox)
                                .scaleEffect(0.8)
                        }
                        .padding(8)
                        .background(Color.primary.opacity(0.02))
                        .cornerRadius(8)
                        .overlay(
                            RoundedRectangle(cornerRadius: 8)
                                .stroke(Color.primary.opacity(0.05), lineWidth: 1)
                        )
                    }
                }
                .padding(.trailing, 4)
            }
        }
    }
    
    private func exportPresetFile(preset: PEQPreset) {
        let savePanel = NSSavePanel()
        savePanel.allowedContentTypes = [.plainText]
        savePanel.nameFieldStringValue = "\(preset.name)_APO.txt"
        savePanel.begin { response in
            if response == .OK, let url = savePanel.url {
                let text = presetManager.exportToEqualizerAPO(preset: preset)
                try? text.write(to: url, atomically: true, encoding: .utf8)
            }
        }
    }
    
    private func saveRename(preset: PEQPreset) {
        let cleanName = renamingText.trimmingCharacters(in: .whitespacesAndNewlines)
        if !cleanName.isEmpty {
            var updated = preset
            updated.name = cleanName
            presetManager.updatePreset(updated)
            if selectedPresetID == preset.id {
                applyPresetToEngine(updated.id)
            }
        }
        renamingPresetID = nil
    }
    
    private var importURLSheet: some View {
        VStack(spacing: 16) {
            Text("Import Preset from URL")
                .font(.headline)
            
            Text("Paste a raw Equalizer APO (.txt) URL location (e.g. from AutoEq on GitHub).")
                .font(.subheadline)
                .foregroundColor(.secondary)
                .multilineTextAlignment(.center)
            
            TextField("https://raw.githubusercontent.com/...", text: $importURLString)
                .textFieldStyle(.roundedBorder)
            
            if !importError.isEmpty {
                Text(importError)
                    .foregroundColor(.red)
                    .font(.caption)
            }
            
            HStack {
                Button("Cancel") {
                    showImportSheet = false
                }
                .keyboardShortcut(.cancelAction)
                
                Spacer()
                
                Button("Download & Parse") {
                    guard let url = URL(string: importURLString) else {
                        importError = "Invalid URL structure."
                        return
                    }
                    presetManager.fetchPresetFromURL(url) { preset in
                        if let preset = preset {
                            presetManager.addPreset(preset)
                            selectedPresetID = preset.id
                            showImportSheet = false
                        } else {
                            importError = "Failed to fetch or parse the preset. Verify it matches Equalizer APO formats."
                        }
                    }
                }
                .buttonStyle(.borderedProminent)
                .keyboardShortcut(.defaultAction)
            }
        }
        .padding()
        .frame(width: 480, height: 200)
    }
    
    private var importPasteSheet: some View {
        VStack(spacing: 16) {
            Text("Paste Parametric EQ Text")
                .font(.headline)
            
            Text("Paste standard Equalizer APO configuration text lines below:")
                .font(.subheadline)
                .foregroundColor(.secondary)
            
            TextEditor(text: $importPasteText)
                .font(.system(.body, design: .monospaced))
                .cornerRadius(6)
                .overlay(
                    RoundedRectangle(cornerRadius: 6)
                        .stroke(Color.white.opacity(0.1), lineWidth: 1)
                )
                .frame(height: 180)
            
            if !importError.isEmpty {
                Text(importError)
                    .foregroundColor(.red)
                    .font(.caption)
            }
            
            HStack {
                Button("Cancel") {
                    showPasteSheet = false
                }
                .keyboardShortcut(.cancelAction)
                
                Spacer()
                
                Button("Import Preset") {
                    let defaultName = "Custom Imported EQ"
                    if let preset = presetManager.parseEqualizerAPO(importPasteText, name: defaultName) {
                        presetManager.addPreset(preset)
                        selectedPresetID = preset.id
                        showPasteSheet = false
                    } else {
                        importError = "Could not parse valid filters. Check format matches: 'Filter [x]: ON PK Fc ...'"
                    }
                }
                .buttonStyle(.borderedProminent)
                .keyboardShortcut(.defaultAction)
            }
        }
        .padding()
        .frame(width: 500, height: 350)
    }
    
    // MARK: - Logic Helpers
    
    private func initializePresetSelection() {
        if let first = presetManager.presets.first {
            selectedPresetID = first.id
            applyPresetToEngine(first.id)
        }
    }
    
    private func applyPresetToEngine(_ presetID: UUID?) {
        guard let id = presetID else { return }
        if let preset = presetManager.presets.first(where: { $0.id == id }) {
            audioEngine.bands = preset.bands
            audioEngine.preamp = preset.preamp
            audioEngine.balance = preset.balance
        }
    }
    
    private func saveActivePresetChanges() {
        guard let activeID = selectedPresetID else { return }
        if let index = presetManager.presets.firstIndex(where: { $0.id == activeID }) {
            presetManager.presets[index].bands = audioEngine.bands
            presetManager.presets[index].preamp = audioEngine.preamp
            presetManager.presets[index].balance = audioEngine.balance
            presetManager.savePresets()
        }
    }
    

    
    private func legendItem(color: Color, label: String, isDashed: Bool) -> some View {
        HStack(spacing: 4) {
            if isDashed {
                Line()
                    .stroke(color, style: StrokeStyle(lineWidth: 2, dash: [3, 3]))
                    .frame(width: 16, height: 2)
            } else {
                RoundedRectangle(cornerRadius: 1)
                    .fill(color)
                    .frame(width: 16, height: 3)
            }
            Text(label)
                .font(.system(size: 10, weight: .semibold))
                .foregroundColor(.primary.opacity(0.7))
        }
    }
}

struct BandRowView: View {
    @Binding var band: PEQBand
    let index: Int
    
    var body: some View {
        HStack(spacing: 12) {
            BandPowerButton(isEnabled: $band.isEnabled)
            
            Text("\(index + 1)")
                .font(.system(size: 9, weight: .bold, design: .monospaced))
                .foregroundColor(.secondary)
                .frame(width: 14)
            
            Picker("", selection: $band.type) {
                ForEach(EQType.allCases, id: \.self) { type in
                    Text(type.rawValue).tag(type)
                }
            }
            .pickerStyle(.menu)
            .labelsHidden()
            .frame(width: 60)
            .scaleEffect(0.9)
            
            HStack(spacing: 2) {
                TextField("", value: $band.frequency, formatter: NumberFormatter.integerFormatter)
                    .font(.system(.body, design: .monospaced))
                    .multilineTextAlignment(.trailing)
                    .frame(width: 45)
                    .textFieldStyle(.plain)
                    .padding(3)
                    .background(Color.black.opacity(0.3))
                    .cornerRadius(4)
                Text("Hz")
                    .font(.system(size: 9, weight: .semibold))
                    .foregroundColor(.secondary)
            }
            
            CustomSlider(
                value: $band.gain,
                range: -12.0...12.0,
                activeColor: band.gain >= 0 ? Color.green : Color.red
            )
            .frame(minWidth: 80)
            
            Text(String(format: "%+.1f dB", band.gain))
                .font(.system(size: 10, weight: .bold, design: .monospaced))
                .foregroundColor(band.gain >= 0 ? .green : .red)
                .frame(width: 55, alignment: .trailing)
            
            HStack(spacing: 2) {
                Text("Q:")
                    .font(.system(size: 9, weight: .semibold))
                    .foregroundColor(.secondary)
                TextField("", value: $band.q, formatter: NumberFormatter.decimalFormatter)
                    .font(.system(.body, design: .monospaced))
                    .multilineTextAlignment(.leading)
                    .frame(width: 32)
                    .textFieldStyle(.plain)
                    .padding(3)
                    .background(Color.black.opacity(0.3))
                    .cornerRadius(4)
            }
        }
        .padding(.vertical, 6)
        .padding(.horizontal, 8)
        .background(
            RoundedRectangle(cornerRadius: 8)
                .fill(Color.primary.opacity(band.isEnabled ? 0.03 : 0.01))
                .overlay(
                    RoundedRectangle(cornerRadius: 8)
                        .stroke(band.isEnabled ? Color.purple.opacity(0.15) : Color.clear, lineWidth: 1)
                )
        )
    }
}

struct VisualEffectView: NSViewRepresentable {
    let material: NSVisualEffectView.Material
    let blendingMode: NSVisualEffectView.BlendingMode
    
    func makeNSView(context: Context) -> NSVisualEffectView {
        let view = NSVisualEffectView()
        view.material = material
        view.blendingMode = blendingMode
        view.state = .active
        return view
    }
    
    func updateNSView(_ nsView: NSVisualEffectView, context: Context) {
        nsView.material = material
        nsView.blendingMode = blendingMode
    }
}

struct Line: Shape {
    func path(in rect: CGRect) -> Path {
        var path = Path()
        path.move(to: CGPoint(x: rect.minX, y: rect.midY))
        path.addLine(to: CGPoint(x: rect.maxX, y: rect.midY))
        return path
    }
}

extension NumberFormatter {
    static let integerFormatter: NumberFormatter = {
        let formatter = NumberFormatter()
        formatter.numberStyle = .none
        formatter.minimumFractionDigits = 0
        formatter.maximumFractionDigits = 0
        return formatter
    }()
    
    static let decimalFormatter: NumberFormatter = {
        let formatter = NumberFormatter()
        formatter.numberStyle = .decimal
        formatter.minimumFractionDigits = 1
        formatter.maximumFractionDigits = 2
        return formatter
    }()
}

struct LevelMeter: View {
    var label: String
    var value: Float
    
    var body: some View {
        let dbValue: Float = value > 0.0001 ? 20.0 * log10(value) : -80.0
        let minDb: Float = -60.0
        let progress = value > 0.0001 ? max(0.0, min(1.0, (dbValue - minDb) / -minDb)) : 0.0
        
        let segmentsCount = 18
        
        return HStack(spacing: 6) {
            Text(label)
                .font(.system(size: 10, weight: .bold, design: .monospaced))
                .foregroundColor(.primary.opacity(0.5))
                .frame(width: 12, alignment: .leading)
            
            HStack(spacing: 2) {
                ForEach(0..<segmentsCount, id: \.self) { index in
                    let segProgress = Double(index) / Double(segmentsCount)
                    let isActive = Double(progress) >= segProgress
                    
                    let segColor: Color = {
                        if index > Int(Double(segmentsCount) * 0.85) {
                            return Color.red
                        } else if index > Int(Double(segmentsCount) * 0.65) {
                            return Color.orange
                        } else {
                            return Color.green
                        }
                    }()
                    
                    RoundedRectangle(cornerRadius: 1)
                        .fill(isActive ? segColor : Color.primary.opacity(0.06))
                        .frame(height: 7)
                        .shadow(color: isActive ? segColor.opacity(0.6) : .clear, radius: isActive ? 2 : 0)
                }
            }
        }
    }
}

struct AudioLevelsView: View {
    @ObservedObject var monitor: AudioLevelMonitor
    
    var body: some View {
        VStack(spacing: 10) {
            LevelMeter(label: "L", value: monitor.levelLeft)
            LevelMeter(label: "R", value: monitor.levelRight)
        }
    }
}

struct SessionStatsView: View {
    let audioEngine: AudioEngineManager
    @Binding var selectedPresetID: UUID?
    @ObservedObject var presetManager: PresetManager
    
    @State private var sessionSeconds = 0
    @State private var timer: Timer? = nil
    
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("SESSION STATS")
                .font(.system(size: 10, weight: .bold))
                .foregroundColor(.secondary)
            
            HStack {
                Image(systemName: "headphones")
                    .foregroundColor(.green)
                Text("Active: \(formatTime(seconds: sessionSeconds))")
                    .font(.system(.body, design: .monospaced))
            }
            
            if let activeID = selectedPresetID, let preset = presetManager.presets.first(where: { $0.id == activeID }) {
                Text("Tuning: \(preset.name)")
                    .font(.caption)
                    .foregroundColor(.secondary)
                    .lineLimit(1)
            }
        }
        .padding()
        .background(Color.primary.opacity(0.04))
        .cornerRadius(12)
        .onAppear {
            startSessionTimer()
        }
        .onDisappear {
            timer?.invalidate()
        }
    }
    
    private func startSessionTimer() {
        timer = Timer.scheduledTimer(withTimeInterval: 1.0, repeats: true) { _ in
            if audioEngine.isRunning {
                sessionSeconds += 1
            }
        }
    }
    
    private func formatTime(seconds: Int) -> String {
        let hrs = seconds / 3600
        let mins = (seconds % 3600) / 60
        let secs = seconds % 60
        return String(format: "%02d:%02d:%02d", hrs, mins, secs)
    }
}

struct CustomSlider: View {
    @Binding var value: Double
    let range: ClosedRange<Double>
    let activeColor: Color
    
    var body: some View {
        GeometryReader { geo in
            let width = geo.size.width
            let pct = CGFloat((value - range.lowerBound) / (range.upperBound - range.lowerBound))
            
            ZStack(alignment: .leading) {
                RoundedRectangle(cornerRadius: 2)
                    .fill(Color.primary.opacity(0.15))
                    .frame(height: 4)
                
                RoundedRectangle(cornerRadius: 2)
                    .fill(activeColor)
                    .frame(width: width * pct, height: 4)
                    
                Circle()
                    .fill(Color.white)
                    .overlay(Circle().stroke(Color.gray.opacity(0.3), lineWidth: 0.5))
                    .frame(width: 12, height: 12)
                    .shadow(color: Color.black.opacity(0.15), radius: 2, x: 0, y: 1)
                    .position(x: width * pct, y: geo.size.height / 2)
            }
            .contentShape(Rectangle())
            .gesture(
                DragGesture(minimumDistance: 0)
                    .onChanged { gesture in
                        let locationX = gesture.location.x
                        let newPct = Double(max(0.0, min(1.0, locationX / width)))
                        let newValue = range.lowerBound + newPct * (range.upperBound - range.lowerBound)
                        value = newValue
                    }
            )
        }
        .frame(height: 12)
    }
}

struct BandPowerButton: View {
    @Binding var isEnabled: Bool
    
    var body: some View {
        Button(action: {
            isEnabled.toggle()
        }) {
            ZStack {
                Circle()
                    .fill(isEnabled ? Color.purple.opacity(0.2) : Color.primary.opacity(0.05))
                    .frame(width: 20, height: 20)
                    .overlay(
                        Circle()
                            .stroke(isEnabled ? Color.purple : Color.primary.opacity(0.2), lineWidth: 1)
                    )
                
                Image(systemName: "power")
                    .font(.system(size: 10, weight: .bold))
                    .foregroundColor(isEnabled ? .purple : .secondary)
                    .shadow(color: isEnabled ? .purple : .clear, radius: 2)
            }
        }
        .buttonStyle(.plain)
    }
}

struct PulsingPlayButton: View {
    @ObservedObject var audioEngine: AudioEngineManager
    @State private var pulseScale: CGFloat = 1.0
    
    var body: some View {
        Button(action: {
            if audioEngine.isRunning {
                audioEngine.stop()
            } else {
                audioEngine.start()
            }
        }) {
            HStack(spacing: 8) {
                if audioEngine.isRunning {
                    HStack(spacing: 2) {
                        ForEach(0..<4) { i in
                            RoundedRectangle(cornerRadius: 1)
                                .fill(Color.white)
                                .frame(width: 2, height: audioEngine.isRunning ? CGFloat.random(in: 8...18) : 4)
                                .animation(
                                    audioEngine.isRunning ? 
                                    Animation.linear(duration: 0.4).repeatForever(autoreverses: true).delay(Double(i) * 0.1) :
                                    .default,
                                    value: audioEngine.isRunning
                                )
                        }
                    }
                    .frame(height: 20)
                    Text("Stop Routing Loop")
                        .fontWeight(.bold)
                } else {
                    Image(systemName: "play.fill")
                        .font(.title3)
                    Text("Activate Loopback")
                        .fontWeight(.bold)
                }
            }
            .frame(maxWidth: .infinity, minHeight: 38)
            .background(
                ZStack {
                    if audioEngine.isRunning {
                        LinearGradient(colors: [Color.red.opacity(0.85), Color.orange.opacity(0.85)], startPoint: .leading, endPoint: .trailing)
                            .cornerRadius(10)
                        
                        RoundedRectangle(cornerRadius: 10)
                            .stroke(Color.red, lineWidth: pulseScale > 1.0 ? 0.5 : 2.0)
                            .scaleEffect(pulseScale)
                            .opacity(pulseScale > 1.0 ? 0.0 : 0.8)
                    } else {
                        LinearGradient(colors: [Color.purple, Color.indigo], startPoint: .leading, endPoint: .trailing)
                            .cornerRadius(10)
                    }
                }
            )
            .foregroundColor(.white)
            .shadow(color: audioEngine.isRunning ? Color.red.opacity(0.4) : Color.purple.opacity(0.3), radius: 8, x: 0, y: 4)
        }
        .buttonStyle(.plain)
        .onChange(of: audioEngine.isRunning) {
            if audioEngine.isRunning {
                withAnimation(Animation.easeInOut(duration: 1.2).repeatForever(autoreverses: false)) {
                    pulseScale = 1.3
                }
            } else {
                pulseScale = 1.0
            }
        }
    }
}

struct ChannelSwapRow: View {
    @Binding var isSwapped: Bool
    
    var body: some View {
        HStack {
            VStack(alignment: .leading, spacing: 2) {
                Text("Channel Swap")
                    .font(.system(size: 12, weight: .semibold))
                Text("Reverse L/R earbud channels")
                    .font(.system(size: 9))
                    .foregroundColor(.primary.opacity(0.5))
            }
            
            Spacer()
            
            Button(action: {
                withAnimation(.spring(response: 0.3, dampingFraction: 0.6)) {
                    isSwapped.toggle()
                }
            }) {
                RoundedRectangle(cornerRadius: 10)
                    .fill(isSwapped ? Color.orange : Color.primary.opacity(0.1))
                    .frame(width: 36, height: 20)
                    .overlay(
                        Circle()
                            .fill(Color.white)
                            .frame(width: 16, height: 16)
                            .offset(x: isSwapped ? 8 : -8)
                            .shadow(radius: 2)
                    )
            }
            .buttonStyle(.plain)
        }
        .padding(.vertical, 8)
        .padding(.horizontal, 12)
        .background(
            RoundedRectangle(cornerRadius: 10)
                .fill(Color.primary.opacity(0.03))
                .overlay(
                    RoundedRectangle(cornerRadius: 10)
                        .stroke(isSwapped ? Color.orange.opacity(0.3) : Color.primary.opacity(0.1), lineWidth: 1)
                )
        )
    }
}

struct EQBypassRow: View {
    @Binding var isBypassed: Bool
    
    var body: some View {
        HStack {
            VStack(alignment: .leading, spacing: 2) {
                Text("Equalizer Engine")
                    .font(.system(size: 12, weight: .semibold))
                Text(isBypassed ? "EQ filters bypassed" : "EQ filters active")
                    .font(.system(size: 9))
                    .foregroundColor(isBypassed ? .red.opacity(0.8) : .green.opacity(0.8))
            }
            
            Spacer()
            
            Button(action: {
                withAnimation(.spring(response: 0.3, dampingFraction: 0.6)) {
                    isBypassed.toggle()
                }
            }) {
                RoundedRectangle(cornerRadius: 10)
                    .fill(isBypassed ? Color.red : Color.green)
                    .frame(width: 36, height: 20)
                    .overlay(
                        Circle()
                            .fill(Color.white)
                            .frame(width: 16, height: 16)
                            .offset(x: isBypassed ? 8 : -8)
                            .shadow(radius: 2)
                    )
            }
            .buttonStyle(.plain)
        }
        .padding(.vertical, 8)
        .padding(.horizontal, 12)
        .background(
            RoundedRectangle(cornerRadius: 10)
                .fill(Color.primary.opacity(0.03))
                .overlay(
                    RoundedRectangle(cornerRadius: 10)
                        .stroke(isBypassed ? Color.red.opacity(0.3) : Color.green.opacity(0.3), lineWidth: 1)
                )
        )
    }
}

struct ForceTouchView: NSViewRepresentable {
    var onForceTouch: () -> Void
    var onTap: () -> Void
    
    func makeNSView(context: Context) -> NSView {
        let view = NSView()
        
        let recognizer = NSPressGestureRecognizer(target: context.coordinator, action: #selector(Coordinator.handlePressure(_:)))
        recognizer.delegate = context.coordinator
        recognizer.delaysPrimaryMouseButtonEvents = false
        view.addGestureRecognizer(recognizer)
        
        let clickRecognizer = NSClickGestureRecognizer(target: context.coordinator, action: #selector(Coordinator.handleClick(_:)))
        clickRecognizer.delegate = context.coordinator
        view.addGestureRecognizer(clickRecognizer)
        
        return view
    }
    
    func updateNSView(_ nsView: NSView, context: Context) {}
    
    func makeCoordinator() -> Coordinator {
        Coordinator(onForceTouch: onForceTouch, onTap: onTap)
    }
    
    class Coordinator: NSObject, NSGestureRecognizerDelegate {
        var onForceTouch: () -> Void
        var onTap: () -> Void
        
        init(onForceTouch: @escaping () -> Void, onTap: @escaping () -> Void) {
            self.onForceTouch = onForceTouch
            self.onTap = onTap
        }
        
        @objc func handlePressure(_ sender: NSPressGestureRecognizer) {
            if sender.state == .recognized {
                onForceTouch()
            }
        }
        
        @objc func handleClick(_ sender: NSClickGestureRecognizer) {
            if sender.state == .recognized {
                onTap()
            }
        }
        
        func gestureRecognizer(_ gestureRecognizer: NSGestureRecognizer, shouldRecognizeSimultaneouslyWith otherGestureRecognizer: NSGestureRecognizer) -> Bool {
            return true
        }
    }
}


