import SwiftUI
import Combine

struct ChartNode: Identifiable {
    let id: UUID
    var x: CGFloat
    var y: CGFloat
    var bandIndex: Int
}

public struct InteractiveChartView: View {
    @Environment(\.colorScheme) var colorScheme
    
    @Binding public var bands: [PEQBand]
    @Binding public var preamp: Double
    public var sampleRate: Double
    public var spectrumPublisher: PassthroughSubject<[Float], Never>
    public var initialSpectrum: [Float]
    
    private let minFreq = 20.0
    private let maxFreq = 20000.0
    private let minGain = -15.0
    private let maxGain = 15.0
    
    // Internal margins so handles never render outside the card bounds
    private let paddingX: CGFloat = 16
    private let paddingY: CGFloat = 16
    
    @State private var activeDragID: UUID? = nil
    @State private var selectedBandID: UUID? = nil
    @State private var hoveredBandID: UUID? = nil
    @State private var showRawCurve = true
    @State private var showCorrectedCurve = true
    
    public init(bands: Binding<[PEQBand]>, preamp: Binding<Double>, sampleRate: Double, spectrumPublisher: PassthroughSubject<[Float], Never>, initialSpectrum: [Float]) {
        self._bands = bands
        self._preamp = preamp
        self.sampleRate = sampleRate
        self.spectrumPublisher = spectrumPublisher
        self.initialSpectrum = initialSpectrum
    }
    
    // Dynamic theme colors
    private var chartBackgroundColors: [Color] {
        if colorScheme == .dark {
            return [Color(red: 0.04, green: 0.06, blue: 0.1), Color(red: 0.08, green: 0.09, blue: 0.15)]
        } else {
            return [Color(red: 0.96, green: 0.97, blue: 0.99), Color(red: 0.92, green: 0.94, blue: 0.97)]
        }
    }
    
    private var chartBorderColors: [Color] {
        if colorScheme == .dark {
            return [Color.white.opacity(0.15), Color.white.opacity(0.03)]
        } else {
            return [Color.black.opacity(0.1), Color.black.opacity(0.03)]
        }
    }
    
    public var body: some View {
        GeometryReader { geo in
            let size = geo.size
            
            ZStack(alignment: .topTrailing) {
                ZStack {
                    chartGrid(size: size)
                    SpectrumVisualizerView(
                        publisher: spectrumPublisher,
                        initialSpectrum: initialSpectrum,
                        width: size.width,
                        height: size.height,
                        paddingX: paddingX,
                        paddingY: paddingY,
                        colorScheme: colorScheme
                    )
                    chartCurves(size: size)
                    chartHandles(size: size)
                }
                .gesture(
                    DragGesture(minimumDistance: 0)
                        .onChanged { value in
                            handleDrag(location: value.location, size: size)
                        }
                        .onEnded { _ in
                            activeDragID = nil
                        }
                )
                
                // Curve toggle controls in the top-right overlay
                HStack(spacing: 8) {
                    Toggle(isOn: $showRawCurve) {
                        Text("Raw IEM")
                            .font(.system(size: 8, weight: .semibold))
                            .foregroundColor(.red.opacity(0.8))
                    }
                    .toggleStyle(.button)
                    .controlSize(.mini)
                    
                    Toggle(isOn: $showCorrectedCurve) {
                        Text("Corrected Target")
                            .font(.system(size: 8, weight: .semibold))
                            .foregroundColor(colorScheme == .dark ? Color(red: 0.1, green: 0.8, blue: 0.8) : Color(red: 0.05, green: 0.6, blue: 0.6))
                    }
                    .toggleStyle(.button)
                    .controlSize(.mini)
                }
                .padding(10)
            }
            .background(
                RoundedRectangle(cornerRadius: 16)
                    .fill(LinearGradient(colors: chartBackgroundColors, startPoint: .top, endPoint: .bottom))
                    .overlay(
                        RoundedRectangle(cornerRadius: 16)
                            .stroke(LinearGradient(colors: chartBorderColors, startPoint: .topLeading, endPoint: .bottomTrailing), lineWidth: 1)
                    )
                    .shadow(color: colorScheme == .dark ? Color.black.opacity(0.3) : Color.black.opacity(0.08), radius: 8, x: 0, y: 4)
            )
            .clipShape(RoundedRectangle(cornerRadius: 16))
        }
    }
    

    
    private func getX(freq: Double, width: CGFloat) -> CGFloat {
        let logMin = log10(minFreq)
        let logMax = log10(maxFreq)
        let pct = (log10(freq) - logMin) / (logMax - logMin)
        return paddingX + pct * (width - 2 * paddingX)
    }
    
    private func getFreq(x: CGFloat, width: CGFloat) -> Double {
        let logMin = log10(minFreq)
        let logMax = log10(maxFreq)
        let chartWidth = width - 2 * paddingX
        let clampedX = max(0, min(chartWidth, x - paddingX))
        let pct = Double(clampedX / chartWidth)
        let logVal = logMin + pct * (logMax - logMin)
        return pow(10.0, logVal)
    }
    
    private func getY(gain: Double, height: CGFloat) -> CGFloat {
        let pct = (gain - minGain) / (maxGain - minGain)
        return paddingY + (1.0 - pct) * (height - 2 * paddingY)
    }
    
    private func getGain(y: CGFloat, height: CGFloat) -> Double {
        let chartHeight = height - 2 * paddingY
        let clampedY = max(0, min(chartHeight, y - paddingY))
        let pct = Double(1.0 - (clampedY / chartHeight))
        return minGain + pct * (maxGain - minGain)
    }
    
    private func rawIEMDeviation(_ f: Double) -> Double {
        let bassLoss = -3.0 * exp(-pow(log2(f / 35.0), 2.0) / 1.0)
        let midDip = -1.5 * exp(-pow(log2(f / 700.0), 2.0) / 0.8)
        let presenceBoost = 2.0 * exp(-pow(log2(f / 2800.0), 2.0) / 0.5)
        let sibilancePeak = 5.0 * exp(-pow(log2(f / 4800.0), 2.0) / 0.15)
        let airLoss = -4.0 * exp(-pow(log2(f / 15000.0), 2.0) / 0.5)
        
        return bassLoss + midDip + presenceBoost + sibilancePeak + airLoss
    }
    
    private func chartGrid(size: CGSize) -> some View {
        let isDark = colorScheme == .dark
        let majorLineColor = isDark ? Color.white.opacity(0.3) : Color.primary.opacity(0.2)
        let minorLineColor = isDark ? Color.white.opacity(0.08) : Color.primary.opacity(0.05)
        let labelColor = isDark ? Color.white.opacity(0.4) : Color.primary.opacity(0.5)
        
        return Canvas { context, size in
            let w = size.width
            let h = size.height
            
            let chartLeft = paddingX
            let chartRight = w - paddingX
            let chartTop = paddingY
            let chartBottom = h - paddingY
            
            let gains = [-12.0, -9.0, -6.0, -3.0, 0.0, 3.0, 6.0, 9.0, 12.0]
            for gain in gains {
                let y = getY(gain: gain, height: h)
                var path = Path()
                path.move(to: CGPoint(x: chartLeft, y: y))
                path.addLine(to: CGPoint(x: chartRight, y: y))
                
                context.stroke(
                    path,
                    with: .color(gain == 0 ? majorLineColor : minorLineColor),
                    lineWidth: gain == 0 ? 1.5 : 1.0
                )
                
                context.draw(
                    Text("\(Int(gain)) dB").font(.system(size: 9, weight: .light)).foregroundColor(labelColor),
                    at: CGPoint(x: chartRight - 24, y: y - 6)
                )
            }
            
            let freqs = [20.0, 50.0, 100.0, 200.0, 500.0, 1000.0, 2000.0, 5000.0, 10000.0, 20000.0]
            for freq in freqs {
                let x = getX(freq: freq, width: w)
                var path = Path()
                path.move(to: CGPoint(x: x, y: chartTop))
                path.addLine(to: CGPoint(x: x, y: chartBottom))
                
                context.stroke(
                    path,
                    with: .color(freq == 1000 ? majorLineColor : minorLineColor),
                    lineWidth: 1.0
                )
                
                let label = freq >= 1000 ? String(format: "%g kHz", freq/1000.0) : String(format: "%g Hz", freq)
                context.draw(
                    Text(label).font(.system(size: 9, weight: .light)).foregroundColor(labelColor),
                    at: CGPoint(x: x, y: chartBottom + 2)
                )
            }
        }
    }
    
    private func chartCurves(size: CGSize) -> some View {
        let isDark = colorScheme == .dark
        let rawColor = isDark ? Color.red.opacity(0.25) : Color.red.opacity(0.4)
        let correctedStart = isDark ? Color(red: 0.1, green: 0.8, blue: 0.8) : Color(red: 0.05, green: 0.6, blue: 0.6)
        let correctedEnd = isDark ? Color(red: 0.2, green: 0.9, blue: 0.5) : Color(red: 0.1, green: 0.7, blue: 0.35)
        
        let correctedGradient = Gradient(colors: [correctedStart, correctedEnd])
        let correctedFillGradient = Gradient(colors: [correctedStart.opacity(isDark ? 0.12 : 0.07), .clear])
        
        return Canvas { context, size in
            let w = size.width
            let h = size.height
            let points = 250
            
            var eqPath = Path()
            var rawPath = Path()
            var correctedPath = Path()
            
            var first = true
            
            for i in 0..<points {
                let pct = CGFloat(i) / CGFloat(points - 1)
                let x = paddingX + pct * (w - 2 * paddingX)
                let freq = getFreq(x: x, width: w)
                
                var eqGain = preamp
                for band in bands {
                    eqGain += band.magnitudeAt(frequency: freq, sampleRate: sampleRate)
                }
                let eqY = getY(gain: eqGain, height: h)
                
                let rawGain = rawIEMDeviation(freq)
                let rawY = getY(gain: rawGain, height: h)
                
                let correctedGain = rawGain + eqGain - preamp
                let correctedY = getY(gain: correctedGain, height: h)
                
                if first {
                    eqPath.move(to: CGPoint(x: x, y: eqY))
                    rawPath.move(to: CGPoint(x: x, y: rawY))
                    correctedPath.move(to: CGPoint(x: x, y: correctedY))
                    first = false
                } else {
                    eqPath.addLine(to: CGPoint(x: x, y: eqY))
                    rawPath.addLine(to: CGPoint(x: x, y: rawY))
                    correctedPath.addLine(to: CGPoint(x: x, y: correctedY))
                }
            }
            
            if showRawCurve {
                context.stroke(
                    rawPath,
                    with: .color(rawColor),
                    style: StrokeStyle(lineWidth: 1.5, dash: [4, 4])
                )
            }
            
            context.stroke(
                eqPath,
                with: .linearGradient(
                    Gradient(colors: [.purple, .indigo]),
                    startPoint: CGPoint(x: paddingX, y: 0),
                    endPoint: CGPoint(x: w - paddingX, y: 0)
                ),
                style: StrokeStyle(lineWidth: 2.0)
            )
            
            if showCorrectedCurve {
                context.stroke(
                    correctedPath,
                    with: .linearGradient(
                        correctedGradient,
                        startPoint: CGPoint(x: paddingX, y: 0),
                        endPoint: CGPoint(x: w - paddingX, y: 0)
                    ),
                    style: StrokeStyle(lineWidth: 2.5)
                )
                
                var fillPath = correctedPath
                fillPath.addLine(to: CGPoint(x: w - paddingX, y: h - paddingY))
                fillPath.addLine(to: CGPoint(x: paddingX, y: h - paddingY))
                fillPath.closeSubpath()
                
                context.fill(
                    fillPath,
                    with: .linearGradient(
                        correctedFillGradient,
                        startPoint: CGPoint(x: 0, y: getY(gain: 0, height: h)),
                        endPoint: CGPoint(x: 0, y: h - paddingY)
                    )
                )
            }
        }
    }
    
    private func chartHandles(size: CGSize) -> some View {
        let isDark = colorScheme == .dark
        let strokeColor = isDark ? Color.white.opacity(0.7) : Color.white.opacity(0.9)
        
        return ForEach(Array(bands.enumerated()), id: \.element.id) { idx, band in
            if band.isEnabled {
                let x = getX(freq: band.frequency, width: size.width)
                let y = getY(gain: band.gain, height: size.height)
                let isSelected = selectedBandID == band.id
                let isHovered = hoveredBandID == band.id
                
                ZStack {
                    Circle()
                        .fill(isSelected ? Color.purple.opacity(0.5) : Color.purple.opacity(0.2))
                        .frame(width: 26, height: 26)
                        .scaleEffect(isHovered ? 1.2 : 1.0)
                        .animation(.easeOut(duration: 0.15), value: isHovered)
                    
                    Circle()
                        .stroke(isSelected ? Color.white : strokeColor, lineWidth: 2)
                        .background(Circle().fill(Color.purple))
                        .frame(width: 16, height: 16)
                    
                    Text("\(idx + 1)")
                        .font(.system(size: 9, weight: .bold))
                        .foregroundColor(.white)
                }
                .help(String(format: "Band %d: %.0f Hz, %.1f dB, Q: %.2f", idx + 1, band.frequency, band.gain, band.q))
                .position(x: x, y: y)
                .onHover { hovering in
                    hoveredBandID = hovering ? band.id : nil
                }
                .onTapGesture {
                    selectedBandID = band.id
                }
                .popover(isPresented: Binding(
                    get: { selectedBandID == band.id },
                    set: { if !$0 { selectedBandID = nil } }
                ), arrowEdge: .top) {
                    VStack(alignment: .leading, spacing: 10) {
                        HStack {
                            Text("Band \(idx + 1) Settings")
                                .font(.system(size: 11, weight: .bold))
                                .foregroundColor(.primary)
                            Spacer()
                            Toggle("ON", isOn: $bands[idx].isEnabled)
                                .toggleStyle(.checkbox)
                        }
                        
                        Divider()
                        
                        Picker("Type", selection: $bands[idx].type) {
                            ForEach(EQType.allCases, id: \.self) { type in
                                Text(type.displayName).tag(type)
                            }
                        }
                        .pickerStyle(.menu)
                        
                        VStack(alignment: .leading, spacing: 2) {
                            HStack {
                                Text("Freq").font(.caption).foregroundColor(.secondary)
                                Spacer()
                                Text("\(Int(bands[idx].frequency)) Hz")
                                    .font(.system(size: 10, design: .monospaced))
                            }
                            Slider(value: $bands[idx].frequency, in: 20...20000, step: 1)
                        }
                        
                        if bands[idx].type != .lowPass && bands[idx].type != .highPass {
                            VStack(alignment: .leading, spacing: 2) {
                                HStack {
                                    Text("Gain").font(.caption).foregroundColor(.secondary)
                                    Spacer()
                                    Text(String(format: "%+.1f dB", bands[idx].gain))
                                        .font(.system(size: 10, design: .monospaced))
                                }
                                Slider(value: $bands[idx].gain, in: -15...15, step: 0.1)
                            }
                        }
                        
                        VStack(alignment: .leading, spacing: 2) {
                            HStack {
                                Text("Q-Factor").font(.caption).foregroundColor(.secondary)
                                Spacer()
                                Text(String(format: "%.2f", bands[idx].q))
                                    .font(.system(size: 10, design: .monospaced))
                            }
                            Slider(value: $bands[idx].q, in: 0.1...10.0, step: 0.05)
                        }
                    }
                    .padding(12)
                    .frame(width: 200)
                }
            }
        }
    }
    
    private func handleDrag(location: CGPoint, size: CGSize) {
        let w = size.width
        let h = size.height
        
        if activeDragID == nil {
            var closestID: UUID? = nil
            var minDistance: CGFloat = 30.0
            
            for band in bands {
                guard band.isEnabled else { continue }
                
                let nx = getX(freq: band.frequency, width: w)
                let ny = getY(gain: band.gain, height: h)
                
                let dist = sqrt(pow(nx - location.x, 2.0) + pow(ny - location.y, 2.0))
                if dist < minDistance {
                    minDistance = dist
                    closestID = band.id
                }
            }
            activeDragID = closestID
        }
        
        if let id = activeDragID, let idx = bands.firstIndex(where: { $0.id == id }) {
            let clampedX = max(paddingX, min(w - paddingX, location.x))
            let clampedY = max(paddingY, min(h - paddingY, location.y))
            
            let newFreq = getFreq(x: clampedX, width: w)
            let newGain = getGain(y: clampedY, height: h)
            
            let commonFreqs = [20.0, 31.5, 63.0, 125.0, 250.0, 500.0, 1000.0, 2000.0, 4000.0, 8000.0, 16000.0]
            var snappedFreq = newFreq
            for cf in commonFreqs {
                let cfX = getX(freq: cf, width: w)
                if abs(cfX - clampedX) < 8 {
                    snappedFreq = cf
                    break
                }
            }
            
            var snappedGain = newGain
            let zeroY = getY(gain: 0.0, height: h)
            if abs(zeroY - clampedY) < 4 {
                snappedGain = 0.0
            }
            
            bands[idx].frequency = max(minFreq, min(maxFreq, round(snappedFreq)))
            bands[idx].gain = max(minGain, min(maxGain, Double(String(format: "%.1f", snappedGain)) ?? snappedGain))
        }
    }
}

struct SpectrumVisualizerView: View {
    let publisher: PassthroughSubject<[Float], Never>
    let initialSpectrum: [Float]
    let width: CGFloat
    let height: CGFloat
    let paddingX: CGFloat
    let paddingY: CGFloat
    let colorScheme: ColorScheme
    
    @State private var spectrum: [Float] = Array(repeating: -80.0, count: 32)
    
    var body: some View {
        Canvas { context, size in
            let w = width
            let h = height
            let isDark = colorScheme == .dark
            let fillColor = Color.purple.opacity(isDark ? 0.12 : 0.07)
            
            let binCount = spectrum.count
            guard binCount > 0 else { return }
            
            var path = Path()
            
            for i in 0..<binCount {
                let pct = CGFloat(i) / CGFloat(binCount - 1)
                let x = paddingX + pct * (w - 2 * paddingX)
                
                let db = spectrum[i]
                let normalizedDb = max(-80.0, min(0.0, db))
                let progress = (normalizedDb + 80.0) / 80.0
                
                let y = h - paddingY - (CGFloat(progress) * (h - 2 * paddingY) * 0.45)
                
                if i == 0 {
                    path.move(to: CGPoint(x: x, y: h - paddingY))
                    path.addLine(to: CGPoint(x: x, y: y))
                } else {
                    path.addLine(to: CGPoint(x: x, y: y))
                }
            }
            
            path.addLine(to: CGPoint(x: w - paddingX, y: h - paddingY))
            path.closeSubpath()
            
            context.fill(
                path,
                with: .linearGradient(
                    Gradient(colors: [fillColor, Color.purple.opacity(0.0)]),
                    startPoint: CGPoint(x: 0, y: h - paddingY - (h - 2 * paddingY) * 0.45),
                    endPoint: CGPoint(x: 0, y: h - paddingY)
                )
            )
        }
        .onAppear {
            self.spectrum = initialSpectrum
        }
        .onReceive(publisher) { newSpectrum in
            self.spectrum = newSpectrum
        }
    }
}
