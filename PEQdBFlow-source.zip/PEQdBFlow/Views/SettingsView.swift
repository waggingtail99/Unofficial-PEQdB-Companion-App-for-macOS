import SwiftUI
import ServiceManagement

struct SettingsView: View {
    @Environment(\.dismiss) private var dismiss
    
    @AppStorage("com.vibe.peqdbflow.theme") private var selectedTheme = "Dark"
    @AppStorage("com.vibe.peqdbflow.showDockIcon") private var showDockIcon = true
    @AppStorage("com.vibe.peqdbflow.launchAtLogin") private var launchAtLogin = false
    @AppStorage("com.vibe.peqdbflow.autoStartLoopback") private var autoStartLoopback = false
    
    var body: some View {
        VStack(spacing: 20) {
            // Header
            HStack {
                Image(systemName: "gearshape.fill")
                    .font(.title2)
                    .foregroundColor(.purple)
                Text("PEQdB Flow Settings")
                    .font(.title2)
                    .fontWeight(.bold)
                Spacer()
                Button(action: {
                    dismiss()
                }) {
                    Image(systemName: "xmark.circle.fill")
                        .font(.title2)
                        .foregroundColor(.secondary)
                }
                .buttonStyle(.plain)
            }
            .padding(.bottom, 10)
            
            Divider()
            
            // Settings options
            VStack(alignment: .leading, spacing: 18) {
                // Theme Selection
                VStack(alignment: .leading, spacing: 6) {
                    Text("APPEARANCE")
                        .font(.system(size: 10, weight: .bold))
                        .foregroundColor(.secondary)
                    
                    Picker("", selection: $selectedTheme) {
                        Text("Dark Mode").tag("Dark")
                        Text("Light Mode").tag("Light")
                        Text("System").tag("System")
                    }
                    .pickerStyle(.segmented)
                }
                
                // General Toggles
                VStack(alignment: .leading, spacing: 12) {
                    Text("GENERAL")
                        .font(.system(size: 10, weight: .bold))
                        .foregroundColor(.secondary)
                    
                    Toggle(isOn: $showDockIcon) {
                        VStack(alignment: .leading, spacing: 2) {
                            Text("Show Dock Icon").font(.body)
                            Text("If disabled, app runs only in the menu bar.").font(.caption2).foregroundColor(.secondary)
                        }
                    }
                    .toggleStyle(.checkbox)
                    
                    Toggle(isOn: $launchAtLogin) {
                        VStack(alignment: .leading, spacing: 2) {
                            Text("Open on Startup").font(.body)
                            Text("Launch PEQdB Flow automatically when you log in.").font(.caption2).foregroundColor(.secondary)
                        }
                    }
                    .toggleStyle(.checkbox)
                    
                    Toggle(isOn: $autoStartLoopback) {
                        VStack(alignment: .leading, spacing: 2) {
                            Text("Auto-Activate Loopback").font(.body)
                            Text("Start loopback stream automatically on app launch.").font(.caption2).foregroundColor(.secondary)
                        }
                    }
                    .toggleStyle(.checkbox)
                }
            }
            .padding(.vertical, 10)
            
            Divider()
            
            // Footer/Close button
            Button("Done") {
                dismiss()
            }
            .buttonStyle(.borderedProminent)
            .controlSize(.large)
            .keyboardShortcut(.defaultAction)
        }
        .padding(24)
        .frame(width: 420)
        .preferredColorScheme(selectedTheme == "Dark" ? .dark : selectedTheme == "Light" ? .light : nil)
        .onChange(of: showDockIcon) {
            toggleDockIconVisibility(show: showDockIcon)
        }
        .onChange(of: launchAtLogin) {
            toggleLaunchAtLogin(enabled: launchAtLogin)
        }
    }
    
    private func toggleLaunchAtLogin(enabled: Bool) {
        let service = SMAppService.mainApp
        if enabled {
            try? service.register()
        } else {
            try? service.unregister()
        }
    }
    
    private func toggleDockIconVisibility(show: Bool) {
        if show {
            NSApp.setActivationPolicy(.regular)
        } else {
            NSApp.setActivationPolicy(.accessory)
        }
    }
}
