#!/bin/bash
# Script to automate building the PEQdB Flow app for a proper release.
set -e

# Resolve the absolute path of the project directory
PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$PROJECT_DIR"

echo "=================================================="
echo "1. Generating Xcode project via XcodeGen..."
echo "=================================================="
xcodegen generate

echo "=================================================="
echo "2. Cleaning and building in Release configuration..."
echo "=================================================="
# Build output goes directly to $(pwd)/build/
DEVELOPER_DIR=/Applications/Xcode.app/Contents/Developer \
xcodebuild -project PEQdBFlow.xcodeproj \
           -scheme PEQdBFlow \
           -configuration Release \
           clean build \
           SYMROOT="$PROJECT_DIR/build"

echo "=================================================="
echo "3. Verifying code signature..."
echo "=================================================="
codesign -dvvv "$PROJECT_DIR/build/Release/PEQdBFlow.app"

echo "=================================================="
echo "4. Packaging distribution zip archive..."
echo "=================================================="
cd "$PROJECT_DIR/build/Release"
rm -f PEQdBFlow.zip
zip -r PEQdBFlow.zip PEQdBFlow.app

echo "=================================================="
echo "Release Build Process Completed Successfully!"
echo "Package Path: $PROJECT_DIR/build/Release/PEQdBFlow.zip"
echo "=================================================="
